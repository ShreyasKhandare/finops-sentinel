# FinOps Sentinel — Master Document Source Code
## How to Use, Run, and Extend This File

---

## Quick Start (Run in 60 seconds)

```bash
# 1. Make sure Node.js is installed (v18+ recommended)
node --version

# 2. Install the docx library (one time only)
npm install docx

# 3. Run the document generator
node FinOps_Sentinel_Document_Source.js

# Output: FinOps_Sentinel_Master_Document.docx in the same folder
```

---

## How to Add a New Section

Every section follows the exact same pattern. Copy this block and paste it before the `// FINAL PAGE` comment at the bottom of the file:

```javascript
// ═══════════════════════════════════════════════════════════════
// SECTION N: YOUR SECTION TITLE
// ═══════════════════════════════════════════════════════════════
children.push(
  sectionHeader("N", "Your Section Title Here"),
  new Paragraph({ spacing: sp(200, 0), children: [] }),  // top spacing

  h2("N.1  First Subsection"),
  para("Your paragraph text here."),

  h3("N.1.1  A sub-subsection if needed"),
  para("More text."),
  bullet("A bullet point"),
  bullet([bold("Bold label: "), run("rest of bullet text")]),

  pageBreak()   // always end a section with a page break
);
```

Change `N` to the next section number (e.g., 13, 14, 15...).

---

## Core Building Blocks — Cheat Sheet

### Text Elements

```javascript
// Plain paragraph
para("Your text here")

// Paragraph with mixed formatting
para([
  bold("Bold part "),
  run("normal part "),
  run("italic part", { italics: true }),
  run("colored part", { color: "C0392B" }),  // hex color, no #
])

// Heading levels
h1("Section Title")         // large, navy
h2("Subsection Title")      // medium, teal
h3("Sub-subsection Title")  // smaller, navy

// Bullet point (plain text)
bullet("Your bullet text")

// Bullet point (mixed formatting)
bullet([bold("Label: "), run("description text")])

// Numbered item
numbered("Step one")
numbered("Step two")   // auto-increments

// Page break
pageBreak()

// Horizontal divider line
divider()           // teal color (default)
divider(C.gold)     // gold color
divider(C.navy)     // navy color

// Empty spacing paragraph
new Paragraph({ spacing: sp(100, 0), children: [] })
//                        ^before  ^after  (in twips, 100 twip = ~0.07 inch)
```

### Special Callout Box

```javascript
// callout(label, text, bgColor, accentColor)
callout("NOTE", "Your important message here.", C.light, C.teal)
callout("WARNING", "Something critical.", C.highlight, C.gold)
callout("RULE", "A key rule or principle.", C.light, C.teal)
```

### Section Header Banner (numbered, colored)

```javascript
sectionHeader("13", "Your New Section Name")
// Creates the navy/teal banner with number on left
```

---

## Tables — The 3 Types Used in This Document

### Type 1 — Info Table (2-column label/value)

```javascript
// Best for: requirements, definitions, key-value data
infoTable([
  ["Label One",   "Value or description one"],
  ["Label Two",   "Value or description two"],
  ["Label Three", "Value or description three"],
])
// Rows alternate white/light-blue background automatically
```

### Type 2 — Custom Multi-Column Table

```javascript
// Best for: tech stack, comparisons, detailed data
// Step 1: Define column widths (must sum to 9360 for full-width)
// Step 2: Add a header row
// Step 3: Add data rows

new Table({
  width: { size: 9360, type: WidthType.DXA },
  columnWidths: [2000, 3000, 4360],   // 3 columns, sums to 9360
  rows: [
    // Header row
    new TableRow({ children: [
      ...["Column 1", "Column 2", "Column 3"].map((t, i) =>
        new TableCell({
          borders: cellBorders,
          shading: { fill: C.navy, type: ShadingType.CLEAR },
          width: { size: [2000, 3000, 4360][i], type: WidthType.DXA },
          margins: { top: 100, bottom: 100, left: 120, right: 120 },
          children: [new Paragraph({ children: [
            new TextRun({ text: t, font: "Arial", size: 19, bold: true, color: C.white })
          ]})]
        })
      )
    ]}),
    // Data row
    new TableRow({ children: [
      ...[["Cell A", 2000], ["Cell B", 3000], ["Cell C", 4360]].map(([text, w], i) =>
        new TableCell({
          borders: cellBorders,
          shading: { fill: i%2===0 ? C.white : C.light2, type: ShadingType.CLEAR },
          width: { size: w, type: WidthType.DXA },
          margins: { top: 80, bottom: 80, left: 120, right: 120 },
          children: [new Paragraph({ children: [run(text, { size: 20 })] })]
        })
      )
    ]}),
  ]
})
```

### Type 3 — Phase Card (the big 2-column phase blocks)

```javascript
// Used for the 4 phase breakdowns in Section 3
phaseCard(
  "5",                    // Phase number (string)
  "Week 6 · Days 36–42", // Timeline label
  "Phase Title Here",     // Short title
  "Goal statement here",  // One-line goal
  [                       // Array of task bullet strings
    "Task one description",
    "Task two description",
    "Task three description",
  ],
  [                       // Array of tech introduced
    "New library or tool",
    "Another technology",
  ],
  "Deliverable description here",   // Single string
  [                                  // Metric bullet strings
    "Metric one: value",
    "Metric two: value",
  ],
  C.teal                 // Header color: C.navy / C.teal / C.gold / C.red
)
```

---

## Color Reference

All colors are defined in the `C` object at the top of the file:

```javascript
const C = {
  navy:      "1B2A4A",   // Dark navy blue — section headers, H1, H3
  teal:      "006D77",   // Teal green — H2, accents, teal callouts
  gold:      "C9882A",   // Gold/amber — warnings, highlights
  slate:     "4A5568",   // Dark grey — secondary text
  light:     "EBF4F7",   // Very light blue — callout backgrounds
  light2:    "F5F8FA",   // Off-white — alternating table rows
  white:     "FFFFFF",   // White
  red:       "C0392B",   // Red — warnings, errors, "never use" items
  green:     "1E7E34",   // Green — positive items, good examples
  border:    "CCDDEE",   // Light blue-grey — table borders
  muted:     "6B7280",   // Medium grey — secondary/muted text
  highlight: "FFF3CD",   // Pale yellow — highlight callout backgrounds
}
```

To use in text: `run("text", { color: C.red })`
To use in table shading: `shading: { fill: C.navy, type: ShadingType.CLEAR }`

---

## Typography Reference

```javascript
// Font sizes (in half-points, so 22 = 11pt, 24 = 12pt, 28 = 14pt)
// Standard body text:  size: 22  (11pt)
// Small table text:    size: 19  (9.5pt) or size: 20 (10pt)
// Callout text:        size: 21  (10.5pt)
// H3 heading:          size: 24  (12pt)
// H2 heading:          size: 28  (14pt)
// H1 heading:          size: 34  (17pt)

// Font styling options on run():
run("text", { bold: true })
run("text", { italics: true })
run("text", { color: C.teal })
run("text", { size: 20 })
run("text", { bold: true, color: C.navy, size: 24 })

// bold() is a shortcut for bold+navy:
bold("text")           // navy bold
bold("text", C.teal)   // teal bold
bold("text", C.red)    // red bold
```

---

## Spacing Reference

```javascript
// sp(before, after, lineSpacing)
// before/after are in twips (1440 twips = 1 inch, 20 twips = 1pt)

sp(0, 0)      // no spacing
sp(0, 160)    // standard paragraph spacing (160 twips ≈ 8pt after)
sp(100, 0)    // 100 twip gap above
sp(200, 0)    // small gap after section header
sp(360, 120)  // H1 spacing
sp(280, 100)  // H2 spacing
sp(0, 160, 276)  // body text with 1.38 line spacing

// Usage:
new Paragraph({ spacing: sp(100, 0), children: [] })   // spacer
para("text")  // already has sp(0, 160, 276) built in
```

---

## Common Column Width Combinations

All column widths must sum to **9360 DXA** (the full content width at 1-inch margins on US Letter).

```
Full width (1 col):       [9360]
50/50 split (2 cols):     [4680, 4680]
30/70 split (2 cols):     [2800, 6560]  ← used in infoTable()
Label/Value (2 cols):     [2200, 7160]  ← used in build log table
3 equal cols:             [3120, 3120, 3120]
4 equal cols:             [2340, 2340, 2340, 2340]
Icon + wide (2 cols):     [700, 8660]
Tech stack (5 cols):      [1600, 1100, 1800, 3000, 1860]
Phase card (2 cols):      [5200, 4160]
Timeline (4 cols):        [800, 2100, 2160, 4400] (must sum to 9360... adjust last)
```

---

## File Structure

```
FinOps_Sentinel_Document_Source.js
│
├── IMPORTS & SETUP (lines 1–7)
│   └── require('docx') — all needed classes
│
├── COLORS (C object)
│   └── All hex colors referenced throughout
│
├── BORDER HELPERS
│   ├── bdr()         — creates a border object
│   ├── cellBorders   — standard cell border (all 4 sides)
│   └── noBorders     — invisible border (for decorative tables)
│
├── PARAGRAPH HELPERS
│   ├── sp()          — spacing helper
│   ├── h1/h2/h3()    — heading paragraphs
│   ├── para()        — body paragraph (text or array of runs)
│   ├── run()         — inline text run with options
│   ├── bold()        — shortcut for bold run
│   ├── bullet()      — bulleted list item
│   ├── numbered()    — numbered list item
│   ├── divider()     — horizontal rule
│   └── pageBreak()   — page break paragraph
│
├── TABLE HELPERS
│   ├── callout()        — colored accent callout box
│   ├── sectionHeader()  — numbered section banner
│   ├── infoRow()        — single row for infoTable
│   ├── infoTable()      — 2-column label/value table
│   ├── techRow()        — single row for tech stack table
│   ├── techTableHeader()— header row for tech stack tables
│   └── phaseCard()      — full phase breakdown card
│
├── CONTENT SECTIONS (children array)
│   ├── COVER PAGE
│   ├── TABLE OF CONTENTS
│   ├── SECTION 01 — Project Pitch
│   ├── SECTION 02 — Requirements & Tech Stack
│   ├── SECTION 03 — Project Plan & Timeline
│   ├── SECTION 04 — Repository Structure
│   ├── SECTION 05 — Build Log Template
│   ├── SECTION 06 — Metrics & Success Criteria
│   ├── SECTION 07 — Live Build Log (fill as you go)
│   ├── SECTION 08 — Interview Preparation
│   ├── SECTION 09 — Bonus Features & Roadmap
│   ├── SECTION 10 — Ethics & Job Impact
│   ├── SECTION 11 — AI Tools & Dev Workflow
│   ├── SECTION 12 — Real Datasets & Benchmarks
│   └── FINAL PAGE
│
└── DOCUMENT ASSEMBLY
    ├── numbering config (bullets + numbers)
    ├── paragraph styles (H1, H2, H3 overrides)
    ├── page size (US Letter, 1-inch margins)
    ├── header (right-aligned with title + version)
    ├── footer (centered with page label)
    └── Packer.toBuffer() → writes .docx file
```

---

## How to Update the Document Version

Find this line in the header section of the assembly block (near the bottom):

```javascript
new TextRun({ text: "v1.0", font: "Arial", size: 18, bold: true, color: C.teal }),
```

Change `"v1.0"` to `"v1.1"` or whatever version you are on.

Also update the cover page version text:

```javascript
new TextRun({ text: "Master Project Document  ·  v1.0  ·  March 2026", ... }),
```

---

## Troubleshooting

**"Cannot find module 'docx'"**
```bash
npm install docx
# If that fails:
npm install -g docx
```

**"SyntaxError: Unexpected token"**
You likely have a missing closing bracket or parenthesis somewhere.
Run: `node --check FinOps_Sentinel_Document_Source.js` to find the line.

**"TypeError: X is not a constructor"**
The `docx` library occasionally renames exports between versions.
Check available exports with:
```bash
node -e "const d = require('docx'); console.log(Object.keys(d).filter(k => k[0] === k[0].toUpperCase()))"
```

**Table cells look wrong / black background**
Always use `ShadingType.CLEAR`, never `ShadingType.SOLID`.
```javascript
shading: { fill: "EBF4F7", type: ShadingType.CLEAR }  // ✅ correct
shading: { fill: "EBF4F7", type: ShadingType.SOLID }   // ❌ black background
```

**Bullet points showing as raw characters**
Never use `\u2022` directly in text. Always use the numbering config:
```javascript
// ❌ Wrong
new Paragraph({ children: [new TextRun("• item")] })
// ✅ Correct
bullet("item")   // uses the numbering reference defined at the bottom
```

---

## Quick Recipes for Common Future Updates

### Add a new build log session entry
Find `// SECTION 07` and add a new `h2("Session 00N — [date]")` block with a new table using the session log template from Section 5.

### Add a new tech stack tool
Find the relevant tech stack table in Section 02 and add a new `techRow(...)` line.

### Update a target metric
Find the metrics table in Section 06 and change the value in the relevant row.

### Add a new phase (if project grows beyond 4 phases)
Copy an existing `phaseCard(...)` block in Section 03 and update all fields.

### Change the document title
Search for `"FinOps Sentinel"` and replace all occurrences.

---

*This source file is your single source of truth for the document. Never manually edit the .docx — always edit this .js file and regenerate.*
