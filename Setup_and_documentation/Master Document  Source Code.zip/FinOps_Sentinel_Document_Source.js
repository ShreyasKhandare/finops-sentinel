const {
  Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
  Header, Footer, AlignmentType, HeadingLevel, BorderStyle, WidthType,
  ShadingType, VerticalAlign, PageNumber, PageBreak, LevelFormat,
  TableOfContents, UnderlineType
} = require('docx');
const fs = require('fs');

// ── COLORS ──────────────────────────────────────────────────────────────────
const C = {
  navy:    "1B2A4A",
  teal:    "006D77",
  gold:    "C9882A",
  slate:   "4A5568",
  light:   "EBF4F7",
  light2:  "F5F8FA",
  white:   "FFFFFF",
  red:     "C0392B",
  green:   "1E7E34",
  border:  "CCDDEE",
  muted:   "6B7280",
  highlight: "FFF3CD",
};

// ── BORDER HELPERS ───────────────────────────────────────────────────────────
const bdr = (color = C.border, size = 6) => ({ style: BorderStyle.SINGLE, size, color });
const cellBorders = { top: bdr(), bottom: bdr(), left: bdr(), right: bdr() };
const noBorder = { style: BorderStyle.NONE, size: 0, color: "FFFFFF" };
const noBorders = { top: noBorder, bottom: noBorder, left: noBorder, right: noBorder };

// ── PARAGRAPH HELPERS ────────────────────────────────────────────────────────
const sp = (before = 0, after = 0, line) => ({
  before, after, ...(line ? { line, lineRule: "auto" } : {})
});

function h1(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_1,
    spacing: sp(360, 120),
    children: [new TextRun({ text, font: "Arial", size: 34, bold: true, color: C.navy })]
  });
}

function h2(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_2,
    spacing: sp(280, 100),
    children: [new TextRun({ text, font: "Arial", size: 28, bold: true, color: C.teal })]
  });
}

function h3(text) {
  return new Paragraph({
    heading: HeadingLevel.HEADING_3,
    spacing: sp(200, 80),
    children: [new TextRun({ text, font: "Arial", size: 24, bold: true, color: C.navy })]
  });
}

function para(children, opts = {}) {
  return new Paragraph({
    spacing: sp(0, 160, 276),
    ...opts,
    children: typeof children === 'string'
      ? [new TextRun({ text: children, font: "Arial", size: 22, color: "333333" })]
      : children
  });
}

function run(text, opts = {}) {
  return new TextRun({ text, font: "Arial", size: 22, color: "333333", ...opts });
}

function bold(text, color = C.navy) {
  return new TextRun({ text, font: "Arial", size: 22, bold: true, color });
}

function bullet(text, level = 0, color = "333333") {
  return new Paragraph({
    numbering: { reference: "bullets", level },
    spacing: sp(0, 100, 276),
    children: typeof text === 'string'
      ? [new TextRun({ text, font: "Arial", size: 22, color })]
      : text
  });
}

function numbered(text, ref = "numbers") {
  return new Paragraph({
    numbering: { reference: ref, level: 0 },
    spacing: sp(0, 100, 276),
    children: typeof text === 'string'
      ? [new TextRun({ text, font: "Arial", size: 22, color: "333333" })]
      : text
  });
}

function divider(color = C.teal) {
  return new Paragraph({
    spacing: sp(120, 120),
    border: { bottom: { style: BorderStyle.SINGLE, size: 4, color, space: 1 } },
    children: []
  });
}

function pageBreak() {
  return new Paragraph({ children: [new PageBreak()] });
}

function callout(label, text, bg = C.light, accent = C.teal) {
  return new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [200, 9160],
    rows: [new TableRow({ children: [
      new TableCell({
        borders: noBorders,
        shading: { fill: accent, type: ShadingType.CLEAR },
        width: { size: 200, type: WidthType.DXA },
        margins: { top: 100, bottom: 100, left: 120, right: 120 },
        verticalAlign: VerticalAlign.CENTER,
        children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [
          new TextRun({ text: label, font: "Arial", size: 20, bold: true, color: C.white })
        ]})]
      }),
      new TableCell({
        borders: noBorders,
        shading: { fill: bg, type: ShadingType.CLEAR },
        width: { size: 9160, type: WidthType.DXA },
        margins: { top: 100, bottom: 100, left: 180, right: 180 },
        children: [new Paragraph({ children: [
          new TextRun({ text, font: "Arial", size: 21, color: "333333" })
        ]})]
      })
    ]})]
  });
}

// ── SECTION HEADER TABLE ─────────────────────────────────────────────────────
function sectionHeader(num, title) {
  return new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [800, 8560],
    spacing: { before: 200, after: 100 },
    rows: [new TableRow({ children: [
      new TableCell({
        borders: noBorders,
        shading: { fill: C.navy, type: ShadingType.CLEAR },
        width: { size: 800, type: WidthType.DXA },
        margins: { top: 140, bottom: 140, left: 140, right: 140 },
        verticalAlign: VerticalAlign.CENTER,
        children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [
          new TextRun({ text: num, font: "Arial", size: 32, bold: true, color: C.gold })
        ]})]
      }),
      new TableCell({
        borders: noBorders,
        shading: { fill: C.teal, type: ShadingType.CLEAR },
        width: { size: 8560, type: WidthType.DXA },
        margins: { top: 140, bottom: 140, left: 220, right: 140 },
        verticalAlign: VerticalAlign.CENTER,
        children: [new Paragraph({ children: [
          new TextRun({ text: title, font: "Arial", size: 28, bold: true, color: C.white })
        ]})]
      })
    ]})]
  });
}

// ── SIMPLE 2-COL INFO ROW ─────────────────────────────────────────────────────
function infoRow(label, value, altBg = false) {
  return new TableRow({ children: [
    new TableCell({
      borders: cellBorders,
      shading: { fill: altBg ? "E8F0F5" : C.light, type: ShadingType.CLEAR },
      width: { size: 2800, type: WidthType.DXA },
      margins: { top: 80, bottom: 80, left: 120, right: 120 },
      children: [new Paragraph({ children: [bold(label)] })]
    }),
    new TableCell({
      borders: cellBorders,
      shading: { fill: C.white, type: ShadingType.CLEAR },
      width: { size: 6560, type: WidthType.DXA },
      margins: { top: 80, bottom: 80, left: 120, right: 120 },
      children: [new Paragraph({ children: [run(value)] })]
    })
  ]});
}

function infoTable(rows) {
  return new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [2800, 6560],
    rows: rows.map((r, i) => infoRow(r[0], r[1], i % 2 === 1))
  });
}

// ── TECH STACK ROW ────────────────────────────────────────────────────────────
function techRow(tool, version, role, why, alt, idx) {
  const bg = idx % 2 === 0 ? C.white : C.light2;
  return new TableRow({ children: [
    new TableCell({
      borders: cellBorders, shading: { fill: bg, type: ShadingType.CLEAR },
      width: { size: 1600, type: WidthType.DXA },
      margins: { top: 80, bottom: 80, left: 120, right: 120 },
      children: [new Paragraph({ children: [bold(tool, C.teal)] })]
    }),
    new TableCell({
      borders: cellBorders, shading: { fill: bg, type: ShadingType.CLEAR },
      width: { size: 1100, type: WidthType.DXA },
      margins: { top: 80, bottom: 80, left: 120, right: 120 },
      children: [new Paragraph({ children: [run(version, { size: 20, color: C.muted })] })]
    }),
    new TableCell({
      borders: cellBorders, shading: { fill: bg, type: ShadingType.CLEAR },
      width: { size: 1800, type: WidthType.DXA },
      margins: { top: 80, bottom: 80, left: 120, right: 120 },
      children: [new Paragraph({ children: [run(role, { size: 20 })] })]
    }),
    new TableCell({
      borders: cellBorders, shading: { fill: bg, type: ShadingType.CLEAR },
      width: { size: 3000, type: WidthType.DXA },
      margins: { top: 80, bottom: 80, left: 120, right: 120 },
      children: [new Paragraph({ children: [run(why, { size: 20 })] })]
    }),
    new TableCell({
      borders: cellBorders, shading: { fill: bg, type: ShadingType.CLEAR },
      width: { size: 1860, type: WidthType.DXA },
      margins: { top: 80, bottom: 80, left: 120, right: 120 },
      children: [new Paragraph({ children: [run(alt, { size: 20, color: C.muted })] })]
    })
  ]});
}

function techTableHeader() {
  return new TableRow({ children: [
    ["Tool / Library", 1600], ["Version", 1100], ["Role", 1800],
    ["Why This Over Alternatives", 3000], ["Alternative Considered", 1860]
  ].map(([txt, w]) => new TableCell({
    borders: cellBorders,
    shading: { fill: C.navy, type: ShadingType.CLEAR },
    width: { size: w, type: WidthType.DXA },
    margins: { top: 100, bottom: 100, left: 120, right: 120 },
    children: [new Paragraph({ children: [new TextRun({ text: txt, font: "Arial", size: 20, bold: true, color: C.white })] })]
  }))});
}

// ── PHASE CARD ────────────────────────────────────────────────────────────────
function phaseCard(phaseNum, week, title, goal, tasks, techUsed, deliverable, metrics, color) {
  const rows = [];

  // Phase header
  rows.push(new TableRow({ children: [
    new TableCell({
      columnSpan: 2,
      borders: noBorders,
      shading: { fill: color, type: ShadingType.CLEAR },
      margins: { top: 160, bottom: 160, left: 220, right: 220 },
      children: [
        new Paragraph({ children: [
          new TextRun({ text: `PHASE ${phaseNum}  ·  ${week}  ·  `, font: "Arial", size: 20, color: "AACCDD" }),
          new TextRun({ text: title, font: "Arial", size: 26, bold: true, color: C.white })
        ]}),
        new Paragraph({ spacing: sp(60, 0), children: [
          new TextRun({ text: `Goal: ${goal}`, font: "Arial", size: 20, color: "CCDDEE", italics: true })
        ]})
      ]
    })
  ]}));

  // Tasks + Tech split
  rows.push(new TableRow({ children: [
    new TableCell({
      borders: { top: bdr(color, 4), bottom: bdr(), left: bdr(), right: bdr() },
      shading: { fill: C.white, type: ShadingType.CLEAR },
      width: { size: 5200, type: WidthType.DXA },
      margins: { top: 120, bottom: 120, left: 160, right: 160 },
      children: [
        new Paragraph({ spacing: sp(0, 80), children: [bold("Key Tasks & Features", C.navy)] }),
        ...tasks.map(t => bullet(t))
      ]
    }),
    new TableCell({
      borders: { top: bdr(color, 4), bottom: bdr(), left: bdr(), right: bdr() },
      shading: { fill: C.light2, type: ShadingType.CLEAR },
      width: { size: 4160, type: WidthType.DXA },
      margins: { top: 120, bottom: 120, left: 160, right: 160 },
      children: [
        new Paragraph({ spacing: sp(0, 80), children: [bold("Tech Introduced", C.teal)] }),
        ...techUsed.map(t => bullet(t, 0, C.slate)),
        new Paragraph({ spacing: sp(100, 60), children: [bold("Deliverable", C.navy)] }),
        new Paragraph({ spacing: sp(0, 80), children: [run(deliverable, { size: 21, italics: true })] }),
        new Paragraph({ spacing: sp(80, 60), children: [bold("Target Metrics", C.red)] }),
        ...metrics.map(m => bullet(m, 0, C.red))
      ]
    })
  ]}));

  return new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [5200, 4160],
    rows
  });
}

// ═══════════════════════════════════════════════════════════════════════════
// BUILD DOCUMENT
// ═══════════════════════════════════════════════════════════════════════════
const children = [];

// ── COVER PAGE ───────────────────────────────────────────────────────────────
children.push(
  new Paragraph({ spacing: sp(1200, 0), children: [] }),
  new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: sp(0, 80),
    children: [new TextRun({ text: "PROJECT MASTER DOCUMENT", font: "Arial", size: 22, color: C.muted, characterSpacing: 200 })]
  }),
  new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: sp(0, 60),
    children: [new TextRun({ text: "FinOps Sentinel", font: "Arial", size: 72, bold: true, color: C.navy })]
  }),
  new Paragraph({
    alignment: AlignmentType.CENTER,
    spacing: sp(0, 200),
    children: [new TextRun({ text: "AI Compliance & Code Intelligence Platform for FinTech", font: "Arial", size: 28, color: C.teal, italics: true })]
  }),
  divider(C.gold),
  new Paragraph({ spacing: sp(100, 0), children: [] }),

  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [4680, 4680],
    rows: [
      new TableRow({ children: [
        new TableCell({
          borders: noBorders,
          shading: { fill: C.navy, type: ShadingType.CLEAR },
          width: { size: 4680, type: WidthType.DXA },
          margins: { top: 200, bottom: 200, left: 280, right: 280 },
          children: [
            new Paragraph({ children: [new TextRun({ text: "DOCUMENT DETAILS", font: "Arial", size: 18, bold: true, color: C.gold, characterSpacing: 180 })] }),
            new Paragraph({ spacing: sp(100, 0), children: [] }),
            ...[ ["Author", "AI Engineer Candidate"],
                 ["Version", "v1.0 — Initial Master Doc"],
                 ["Created", "March 2026"],
                 ["Status", "Active — Living Document"],
                 ["Repo", "github.com/[username]/finops-sentinel"],
            ].map(([k, v]) => new Paragraph({ spacing: sp(0, 60), children: [
              new TextRun({ text: `${k}: `, font: "Arial", size: 20, bold: true, color: "AACCEE" }),
              new TextRun({ text: v, font: "Arial", size: 20, color: C.white })
            ]}))
          ]
        }),
        new TableCell({
          borders: noBorders,
          shading: { fill: C.teal, type: ShadingType.CLEAR },
          width: { size: 4680, type: WidthType.DXA },
          margins: { top: 200, bottom: 200, left: 280, right: 280 },
          children: [
            new Paragraph({ children: [new TextRun({ text: "TARGET OUTCOMES", font: "Arial", size: 18, bold: true, color: C.gold, characterSpacing: 180 })] }),
            new Paragraph({ spacing: sp(100, 0), children: [] }),
            ...[
              "AI Engineer / LLM Engineer roles",
              "RegTech / FinTech AI positions",
              "Base salary target: $110K–$150K",
              "Live public demo + full GitHub repo",
              "Production RAG + multi-agent system",
            ].map(t => new Paragraph({ spacing: sp(0, 60), children: [
              new TextRun({ text: "  ✓  ", font: "Arial", size: 20, bold: true, color: C.gold }),
              new TextRun({ text: t, font: "Arial", size: 20, color: C.white })
            ]}))
          ]
        })
      ]})]
  }),

  new Paragraph({ spacing: sp(200, 0), children: [] }),
  new Paragraph({
    alignment: AlignmentType.CENTER,
    children: [new TextRun({ text: "⚠  This is a living document — update the build log after every work session", font: "Arial", size: 20, color: C.gold, italics: true })]
  }),

  pageBreak()
);

// ── TABLE OF CONTENTS ─────────────────────────────────────────────────────────
children.push(
  h1("Table of Contents"),
  new TableOfContents("Contents", {
    hyperlink: true,
    headingStyleRange: "1-3",
    stylesWithLevels: [
      { styleName: "Heading 1", level: 1 },
      { styleName: "Heading 2", level: 2 },
      { styleName: "Heading 3", level: 3 },
    ]
  }),
  pageBreak()
);

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 1: PROJECT PITCH
// ═══════════════════════════════════════════════════════════════════════════
children.push(
  sectionHeader("01", "Project Pitch — What, Why & Who"),
  new Paragraph({ spacing: sp(200, 0), children: [] }),

  h2("1.1  Project Overview"),
  para([
    bold("FinOps Sentinel "), run("is a production-grade, dual-corpus AI system purpose-built for engineering teams inside financial services companies — banks, trading platforms, payment processors, and FinTech startups. It operates at the intersection of two traditionally separate knowledge domains that every FinTech engineering team deals with simultaneously: their "),
    bold("software codebase "), run("and their "), bold("regulatory & compliance document corpus."),
  ]),
  para("The system allows engineers, compliance officers, and technical leads to ask natural-language questions that span both worlds — getting answers synthesized from live code analysis and regulatory text — without switching between tools, manually cross-referencing documents, or waiting for specialist teams to respond."),

  callout("CORE", "FinOps Sentinel = Code Intelligence Engine (like CodeSheriff) + Financial Compliance RAG (like TradeScribe), merged into one agentic system with a shared query interface, dual-corpus retrieval, and a cross-corpus synthesis layer.", C.light, C.teal),
  new Paragraph({ spacing: sp(100, 0), children: [] }),

  h2("1.2  The Problem — What Pain Does This Solve?"),
  h3("Domain 1: The FinTech Codebase Problem"),
  para("Financial software systems are among the most complex, oldest, and most consequential codebases on earth. A mid-sized bank may have 15–50 million lines of code accumulated over 20–30 years. The engineers working on it today did not write most of it. The result:"),
  bullet([bold("Onboarding latency: "), run("New engineers take 3–6 months before they are productive in a legacy financial codebase. Every month of lost productivity costs $15,000–$25,000 per engineer.")]),
  bullet([bold("Change-impact blindness: "), run("Engineers routinely make changes without knowing which downstream services, compliance checks, or audit functions they affect. This causes production incidents at a median cost of $500,000–$1M per major outage.")]),
  bullet([bold("Architectural amnesia: "), run("Documentation is always out of date. The people who understand the system retire or leave. Knowledge lives in people's heads, not in queryable systems.")]),

  new Paragraph({ spacing: sp(80, 0), children: [] }),
  h3("Domain 2: The Financial Compliance Problem"),
  para("Financial companies operate under an ever-expanding web of regulations: PCI-DSS, SOX, MiFID II, Basel III, DORA (EU Digital Operational Resilience Act), SEC rules, FINRA guidelines, AML/KYC requirements, and dozens more. Each regulation is:"),
  bullet([bold("Dense and technical: "), run("A single regulation like PCI-DSS v4.0 runs to 360 pages. DORA's technical standards span 5 separate regulatory documents.")]),
  bullet([bold("Code-relevant: "), run("Most compliance requirements directly mandate specific code behaviors — encryption standards, audit logging, data retention, access controls, transaction limits.")]),
  bullet([bold("Constantly changing: "), run("Regulatory updates are issued multiple times per year. Each change potentially requires code modifications across multiple services.")]),

  new Paragraph({ spacing: sp(80, 0), children: [] }),
  h3("Domain 3: The Gap Between Domains — The Real Problem"),
  para("The most painful problem is not in either domain alone — it's the gap between them. Compliance officers understand regulations but cannot read code. Engineers can read code but do not understand regulatory implications. The result is a slow, expensive, error-prone manual translation process:"),
  bullet("A compliance officer identifies a new regulatory requirement"),
  bullet("They write a memo explaining what needs to change"),
  bullet("The memo goes to a technical lead who translates it into engineering tasks"),
  bullet("Engineers investigate which code is affected — manually, using grep and documentation that may be outdated"),
  bullet("The change is made, often missing edge cases that only a full regulatory + code cross-reference would catch"),
  para([bold("FinOps Sentinel eliminates this entire workflow "), run("by being the shared intelligence layer — understanding both the regulation and the code simultaneously.")]),

  new Paragraph({ spacing: sp(80, 0), children: [] }),
  callout("STAT", "According to Accenture's 2024 Compliance Risk Study, FinTech firms spend an average of $10,000 per employee per year on compliance operations. For a 200-person engineering org, that is $2M/year — much of which is manual cross-referencing of the kind FinOps Sentinel automates.", C.highlight, C.gold),
  new Paragraph({ spacing: sp(100, 0), children: [] }),

  h2("1.3  Our Solution — How FinOps Sentinel Works"),
  para("FinOps Sentinel ingests two separate but linked knowledge corpora and deploys a multi-agent system to reason across them:"),
  new Paragraph({ spacing: sp(80, 0), children: [] }),

  infoTable([
    ["Corpus A: Code", "GitHub repos ingested via API. Code chunked at function and module level using AST parsing (tree-sitter). Embedded with a code-specific model (CodeBERT or nomic-embed-code). Stored in Chroma namespace: 'codebase'."],
    ["Corpus B: Compliance", "Regulatory PDFs, SEC filings, internal compliance policies ingested via LlamaIndex. Chunked by regulation section. Embedded with sentence-transformers. Stored in Chroma namespace: 'compliance'."],
    ["Query Router", "LangGraph supervisor agent classifies every incoming query as CODE / COMPLIANCE / HYBRID and routes to the appropriate retrieval pipeline(s)."],
    ["Dual Retrieval", "Hybrid BM25 + vector retrieval runs independently on each corpus. A reranker (Cohere Rerank or FlashRank) scores combined results."],
    ["Synthesis Agent", "For HYBRID queries, a dedicated synthesis agent merges findings from both corpora into a single coherent, source-attributed answer."],
    ["Evaluation Layer", "RAGAS and DeepEval run continuously. Every answer is scored for faithfulness, context precision, and hallucination rate. Scores are logged to a dashboard."],
  ]),
  new Paragraph({ spacing: sp(100, 0), children: [] }),

  h2("1.4  Why the Financial Domain?"),
  para("This is a question I will be asked in every interview — and the answer must be genuine and data-backed."),
  bullet([bold("Highest salary ceiling for freshers: "), run("Finance and RegTech AI roles at banks and FinTech companies offer $110,000–$150,000 base for engineers who demonstrate domain knowledge alongside LLM skills. This is 20–30% above equivalent roles in other sectors.")]),
  bullet([bold("Scarcity of domain-aware AI engineers: "), run("Over 75% of AI job listings in financial services require domain expertise. Most AI engineers build generic systems. Building a finance-specific, compliance-aware AI system immediately differentiates from 90% of portfolio candidates.")]),
  bullet([bold("Real enterprise pain, real budget: "), run("Financial services firms collectively spend over $270 billion per year on compliance. They have the budget and the urgency to adopt tools that reduce this cost.")]),
  bullet([bold("Emerging regulatory pressure (2025–2026): "), run("DORA (effective January 2025), the EU AI Act, and updated SEC cybersecurity disclosure rules all require new technical capabilities that financial engineering teams are scrambling to build. FinOps Sentinel directly addresses all three.")]),
  bullet([bold("Personal conviction: "), run("The combination of software systems and financial regulation is intellectually interesting and practically impactful. This is not a generic demo — it is a system I would actually use if I were a FinTech engineer.")]),

  new Paragraph({ spacing: sp(80, 0), children: [] }),
  h2("1.5  Target Users & Impact"),
  infoTable([
    ["Primary: FinTech Engineering Teams", "50–500 engineers at banks, trading platforms, payment processors (Stripe, Revolut, Wise). Daily use for code Q&A, compliance mapping, change impact analysis."],
    ["Secondary: Compliance Officers", "Use the compliance corpus to instantly query regulations, compare versions, check which regulations apply to a given system. Replaces manual document search."],
    ["Tertiary: Technical Leads / Architects", "Onboarding new engineers, refactoring legacy systems, preparing for compliance audits."],
    ["Enterprise: Banks & Insurers", "Internal deployment (on-prem Ollama mode) for organizations that cannot send code or financial data to cloud APIs. SOC 2 compliance path."],
    ["Individual: Freelance RegTech Consultants", "Solo practitioners who consult on compliance and need a tool to rapidly audit client codebases against specific regulations."],
  ]),

  new Paragraph({ spacing: sp(80, 0), children: [] }),
  h2("1.6  Monetization Path (Future SaaS)"),
  para("Note: Monetization is a future goal, not the current focus. The priority is building a portfolio-grade system."),
  infoTable([
    ["Free Tier", "1 connected repo, public compliance docs only, 50 queries/month. Designed for individual engineers to try the tool."],
    ["Pro — $49/month", "5 repos, full regulatory corpus, unlimited queries, compliance gap report exports. Target: individual engineers and small dev teams."],
    ["Team — $199/month", "25 repos, team dashboard, Slack integration, change-impact alerts. Target: mid-size FinTech startups."],
    ["Enterprise — $1,500–$5,000/month", "Unlimited repos, on-prem Ollama deployment option, SSO, audit logs, custom regulatory corpus, dedicated support. Target: banks and regulated institutions."],
    ["One-Time Setup", "$3,000–$10,000 implementation fee for enterprise corpus ingestion and custom regulatory mapping. Immediate revenue without subscription lag."],
    ["Long-term API", "Expose the cross-corpus reasoning API for other RegTech tools to build on. B2B API licensing at $0.02–0.05 per query at scale."],
  ]),

  pageBreak()
);

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 2: REQUIREMENTS & TECH STACK
// ═══════════════════════════════════════════════════════════════════════════
children.push(
  sectionHeader("02", "Requirements & Full Tech Stack"),
  new Paragraph({ spacing: sp(200, 0), children: [] }),

  h2("2.1  Hardware Requirements"),
  infoTable([
    ["Development Machine — CPU", "Any modern CPU (Intel i5/i7/i9, AMD Ryzen 5/7/9, Apple M1/M2/M3). No GPU required for API-based models."],
    ["Development Machine — RAM", "Minimum 16 GB RAM recommended. 8 GB workable but slower. 32 GB ideal for running Ollama local models simultaneously."],
    ["Development Machine — Storage", "Minimum 20 GB free disk space. 50 GB recommended for Chroma vector stores, model caches, and Docker images."],
    ["GPU (Optional)", "NVIDIA GPU with 8 GB+ VRAM if running Ollama local models (llama3, mistral) for the privacy mode. Not required if using OpenAI/Anthropic APIs."],
    ["Internet Connection", "Required for API calls (OpenAI, Cohere, Pinecone). Minimum 10 Mbps. Not required for full local mode."],
    ["Cloud Server (Phase 4)", "2 vCPU, 4 GB RAM instance on Render, Railway, or DigitalOcean ($7–$25/month). Free tiers available on Render for initial deployment."],
  ]),
  new Paragraph({ spacing: sp(80, 0), children: [] }),

  h2("2.2  Software Requirements"),
  infoTable([
    ["Operating System", "macOS 12+, Ubuntu 20.04+, or Windows 11 with WSL2. All commands in this document use Unix syntax."],
    ["Python", "3.11.x (NOT 3.12 — LangChain and some LlamaIndex dependencies have known 3.12 issues as of March 2026). Use pyenv for version management."],
    ["Node.js", "18.x LTS (required for some tooling and future frontend work). Use nvm for version management."],
    ["Git", "2.40+ — for version control and GitHub integration. GitHub account required with SSH key configured."],
    ["Docker Desktop", "Latest stable — for containerization in Phase 4. Docker Compose v2 included."],
    ["VS Code", "Latest — recommended IDE. Extensions: Python, Pylance, Docker, GitLens, GitHub Copilot (optional)."],
    ["GitHub Account", "Free tier sufficient. Will need personal access token for repo API calls in Phase 3."],
    ["Postman or Bruno", "For testing FastAPI endpoints. Bruno is open-source and recommended."],
  ]),
  new Paragraph({ spacing: sp(80, 0), children: [] }),

  h2("2.3  External API Accounts (Free Tiers)"),
  infoTable([
    ["OpenAI API", "GPT-4o-mini for primary LLM (cost-efficient at ~$0.15/1M input tokens). gpt-4o for complex synthesis tasks. Free $5 credit on signup."],
    ["Cohere API", "For Cohere Rerank v3 (reranking retrieved chunks). Free tier: 1,000 API calls/month. Significantly improves retrieval precision."],
    ["Pinecone", "Free tier: 1 index, 100,000 vectors — sufficient for Phase 1–2. Alternative to Chroma for cloud-hosted vector store."],
    ["LangSmith", "Free tier: 5,000 traces/month. Used for LangGraph agent observability, tracing, and debugging."],
    ["Anthropic API (Optional)", "Claude 3.5 Sonnet as alternative LLM for specific tasks. Optional but recommended to test multi-model pipelines."],
    ["Supabase", "Free tier: 500 MB database, 50,000 monthly active users. Used for auth, user management, and query analytics in Phase 4."],
    ["GitHub OAuth App", "Free — for allowing users to connect their repositories to FinOps Sentinel in Phase 3–4."],
    ["Render / Railway", "Free tier deployment. Render free tier sleeps after 15 min inactivity (fine for demo). Railway gives $5/month free credit."],
  ]),
  new Paragraph({ spacing: sp(80, 0), children: [] }),

  h2("2.4  Full Tech Stack with Justifications"),
  para("Each tool was selected after evaluating the alternatives. The 'Why This' column explains the decision rationale — memorize this for interviews."),
  new Paragraph({ spacing: sp(80, 0), children: [] }),

  h3("2.4.1  Core AI / LLM Layer"),
  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [1600, 1100, 1800, 3000, 1860],
    rows: [
      techTableHeader(),
      techRow("LangChain", "0.3.x", "Agent orchestration, chains, tool wrappers", "Most mature ecosystem, largest community, best LangSmith integration, thousands of pre-built integrations. Battle-tested in production.", "LlamaIndex (used for indexing)", 0),
      techRow("LlamaIndex", "0.10.x", "Document ingestion, indexing, node parsing", "Superior document parsing pipeline vs LangChain. Better hierarchical node parsing for code and structured PDFs. Both are used: LlamaIndex for ingestion, LangChain for agents.", "LangChain for everything", 1),
      techRow("LangGraph", "0.2.x", "Multi-agent orchestration, state machines", "Only production-ready framework for stateful multi-agent graphs. Built on LangChain. Supports cycles, parallel execution, human-in-the-loop. LangGraph Cloud for deployment.", "AutoGen, CrewAI", 2),
      techRow("GPT-4o-mini", "API", "Primary LLM for retrieval, Q&A", "Best cost-to-performance ratio at $0.15/1M input tokens. Fast (< 1s latency). Sufficient for 90% of tasks. gpt-4o reserved for synthesis.", "Claude 3 Haiku, Llama3", 3),
      techRow("GPT-4o", "API", "Complex cross-corpus synthesis", "Superior reasoning for multi-document synthesis. Used only for final answer generation to control cost. ~10% of queries.", "Claude 3.5 Sonnet", 4),
      techRow("Ollama", "0.4.x", "Local LLM for privacy mode", "Easiest local model server. One command to run llama3.2, mistral, codellama. Required for enterprise on-prem feature. No data leaves the machine.", "LM Studio, vLLM", 5),
      techRow("LangSmith", "Cloud", "Agent tracing, observability, eval", "Native LangGraph integration. Free tier sufficient for dev. Visualizes agent node execution, latency, token usage. Critical for debugging multi-hop queries.", "Helicone, Phoenix Arize", 6),
    ]
  }),
  new Paragraph({ spacing: sp(100, 0), children: [] }),

  h3("2.4.2  Retrieval & Vector Store Layer"),
  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [1600, 1100, 1800, 3000, 1860],
    rows: [
      techTableHeader(),
      techRow("Chroma", "0.5.x", "Primary vector store (local dev)", "Zero-config local vector DB. Persistent storage. Namespace support for dual-corpus separation. No API key. Best for Phase 1–3 development.", "FAISS, Qdrant", 0),
      techRow("Pinecone", "Free tier", "Cloud vector store (Phase 4)", "Managed, scalable, production-ready. Free tier for 100K vectors. Switch from Chroma for deployed SaaS to avoid managing infra.", "Weaviate, Qdrant Cloud", 1),
      techRow("BM25 (rank_bm25)", "0.2.2", "Keyword retrieval component", "Captures exact regulatory terminology (e.g., 'Article 21(3)', 'ISIN code') that vector search misses. BM25 + vector = hybrid retrieval. 20–35% precision improvement.", "Elasticsearch, OpenSearch", 2),
      techRow("Cohere Rerank v3", "API", "Cross-encoder reranking", "Most accurate reranker available via API. Reranks top-20 retrieved chunks to top-5 before LLM. Measurably improves faithfulness by 12–18%.", "FlashRank, BGE Reranker", 3),
      techRow("FlashRank", "0.0.9", "Local reranker (no API needed)", "Runs entirely locally. Use as Cohere fallback or in privacy mode. ms-marco-MiniLM-L-12-v2 model. Good quality, zero cost.", "Cohere Rerank", 4),
      techRow("sentence-transformers", "3.x", "Text embeddings (compliance docs)", "all-MiniLM-L6-v2 for fast local embeddings. BAAI/bge-large for higher quality. No API cost. Runs locally.", "OpenAI text-embedding-3", 5),
      techRow("nomic-embed-code", "via Ollama", "Code-specific embeddings", "Trained specifically on code. Dramatically outperforms generic embeddings for code retrieval. Runs via Ollama locally.", "CodeBERT embeddings", 6),
    ]
  }),
  new Paragraph({ spacing: sp(100, 0), children: [] }),

  h3("2.4.3  Document Processing & Code Parsing Layer"),
  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [1600, 1100, 1800, 3000, 1860],
    rows: [
      techTableHeader(),
      techRow("tree-sitter", "0.22.x", "AST-based code parsing", "Parses Python, JavaScript, TypeScript, Java into abstract syntax trees. Enables function-level chunking (not line-level). 44% precision improvement over naive chunking.", "ast (Python-only), libclang", 0),
      techRow("PyMuPDF (fitz)", "1.24.x", "PDF text + table extraction", "Fastest Python PDF library. Extracts tables, headers, page structure. Better than PyPDF2 for regulatory documents with tables. Critical for compliance corpus.", "PyPDF2, pdfplumber", 1),
      techRow("unstructured", "0.14.x", "Multi-format document loader", "Handles PDF, DOCX, HTML, Markdown, Excel in one unified API. Used for ingesting diverse compliance document formats.", "LangChain document loaders", 2),
      techRow("GitPython", "3.1.x", "GitHub repo cloning + traversal", "Programmatic git operations. Clone repos, traverse file trees, track changes between commits. Used in Phase 3 for live repo connector.", "GitHub REST API (raw)", 3),
      techRow("tiktoken", "0.7.x", "Token counting + chunk sizing", "OpenAI's tokenizer. Ensures chunks stay within LLM context windows. Critical for preventing truncation in long compliance documents.", "transformers tokenizer", 4),
    ]
  }),
  new Paragraph({ spacing: sp(100, 0), children: [] }),

  h3("2.4.4  Evaluation & Quality Layer"),
  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [1600, 1100, 1800, 3000, 1860],
    rows: [
      techTableHeader(),
      techRow("RAGAS", "0.2.x", "RAG evaluation framework", "Industry-standard RAG metrics: faithfulness, answer relevancy, context precision, context recall. Generates automated eval datasets. Most cited in AI Engineer interviews.", "TruLens, Giskard", 0),
      techRow("DeepEval", "1.x", "LLM output quality testing", "Unit-test style evaluation for LLM outputs. Hallucination detection, bias detection, toxicity. Integrates with CI/CD. More developer-friendly than RAGAS for custom metrics.", "Promptfoo, LangSmith Eval", 1),
      techRow("pytest", "8.x", "Testing framework", "Standard Python testing. All RAG pipeline components have unit tests. DeepEval integrates with pytest natively.", "unittest", 2),
    ]
  }),
  new Paragraph({ spacing: sp(100, 0), children: [] }),

  h3("2.4.5  Backend & Deployment Layer"),
  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [1600, 1100, 1800, 3000, 1860],
    rows: [
      techTableHeader(),
      techRow("FastAPI", "0.115.x", "REST API backend", "Async Python web framework. Auto-generates OpenAPI docs. Type safety with Pydantic. 3–5x faster than Flask for I/O-bound AI workloads. Industry standard for AI APIs.", "Flask, Django", 0),
      techRow("Pydantic v2", "2.x", "Data validation + serialization", "Built into FastAPI. Validates all API inputs/outputs. Structured output schemas for LLM responses. 50x faster than Pydantic v1.", "marshmallow, dataclasses", 1),
      techRow("Supabase", "Free tier", "Auth + PostgreSQL database", "Managed Postgres + real-time + auth in one. Free tier is generous. No infra to manage. Supabase Auth handles GitHub OAuth for repo connection.", "Firebase, Auth0 + RDS", 2),
      techRow("Redis (Upstash)", "Free tier", "Rate limiting + caching", "Upstash free tier: 10,000 requests/day. Used for API rate limiting and caching frequent query embeddings. No server to manage.", "Redis self-hosted", 3),
      techRow("Docker + Compose", "Latest", "Containerization", "Package entire app (FastAPI + Chroma + Redis) into reproducible containers. Required for Render/Railway deployment. Industry standard — every job posting mentions Docker.", "Podman, bare metal", 4),
      techRow("Streamlit", "1.40.x", "Phase 1–3 UI (rapid prototyping)", "Zero-config Python UI. Deploy instantly on Streamlit Cloud (free). Ideal for Phase 1–3 demos. Replaced by proper frontend in Phase 4.", "Gradio, Panel", 5),
      techRow("Vercel (Next.js)", "Optional Phase 4", "Production frontend", "Optional: replace Streamlit with a Next.js frontend on Vercel for a more professional demo. Free tier available.", "Netlify, Cloudflare Pages", 6),
      techRow("Render / Railway", "Free–$7/mo", "Backend deployment", "Simple Docker container deployment. Auto-deploy from GitHub. Free tier on Render for demo. Railway gives $5/month credit. Both have one-click Docker deploy.", "AWS, GCP, Azure", 7),
    ]
  }),
  new Paragraph({ spacing: sp(100, 0), children: [] }),

  h3("2.4.6  Observability & Analytics Layer"),
  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [1600, 1100, 1800, 3000, 1860],
    rows: [
      techTableHeader(),
      techRow("LangSmith", "Cloud", "Agent trace visualization", "See every LangGraph node execution, latency, token count, and LLM prompt/response. Essential for debugging multi-agent workflows. Free 5K traces/month.", "Langfuse, Phoenix Arize", 0),
      techRow("PostHog", "Free OSS", "Product analytics", "Track query volumes, user engagement, feature usage. Self-hostable or free cloud tier. Shows investors/employers that you think about product metrics.", "Mixpanel, Amplitude", 1),
      techRow("Loguru", "0.7.x", "Structured logging", "Beautiful, zero-config Python logging. Structured JSON logs for production. Replaces print debugging. Integrated with all pipeline components.", "Python logging, structlog", 2),
    ]
  }),

  pageBreak()
);

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 3: PROJECT PLAN & TIMELINE
// ═══════════════════════════════════════════════════════════════════════════
children.push(
  sectionHeader("03", "Project Plan, Timeline & Phase Execution"),
  new Paragraph({ spacing: sp(200, 0), children: [] }),

  h2("3.1  Project Philosophy & Execution Principles"),
  callout("RULE 1", "Ship a working demo at the end of every phase. A partially-built perfect system is worth nothing. A deployed imperfect system is worth everything.", C.light, C.teal),
  new Paragraph({ spacing: sp(60, 0), children: [] }),
  callout("RULE 2", "Measure everything. Every phase ends with concrete metrics. If you cannot measure the improvement your code made, you did not make a real improvement.", C.highlight, C.gold),
  new Paragraph({ spacing: sp(60, 0), children: [] }),
  callout("RULE 3", "Use AI tools aggressively for boilerplate (70–80% of scaffolding). Use your own brain for architecture decisions, evaluation design, and metric interpretation. Recruiters test judgment, not typing speed.", C.light, C.teal),
  new Paragraph({ spacing: sp(100, 0), children: [] }),

  h2("3.2  Project Timeline Overview"),
  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [1000, 1400, 1400, 5560],
    rows: [
      new TableRow({ children: [
        ...["Phase", "Duration", "Weeks", "Milestone"].map((t, i) => new TableCell({
          borders: cellBorders,
          shading: { fill: C.navy, type: ShadingType.CLEAR },
          width: { size: [1000, 1400, 1400, 5560][i], type: WidthType.DXA },
          margins: { top: 100, bottom: 100, left: 120, right: 120 },
          children: [new Paragraph({ children: [new TextRun({ text: t, font: "Arial", size: 20, bold: true, color: C.white })] })]
        }))
      ]}),
      ...[
        ["1", "7 days", "Week 1", "Basic dual-corpus RAG chatbot with Streamlit UI. Code Q&A + compliance Q&A working separately. Deployed on Streamlit Cloud."],
        ["2", "7 days", "Week 2", "Production-grade RAG: hybrid BM25+vector retrieval, Cohere reranking, RAGAS evaluation suite running, cross-corpus query router prototype."],
        ["3", "7 days", "Week 3", "Full multi-agent system with LangGraph: query router, code analyzer, compliance mapper, synthesis agent. LangSmith tracing live."],
        ["4", "14 days", "Weeks 4–5", "Full SaaS: FastAPI backend, Supabase auth, GitHub OAuth connector, Docker, deployed on Render with live public URL. Analytics dashboard."],
        ["Polish", "7 days", "Week 6", "README with benchmark tables, architecture diagrams, demo video. Portfolio presentation. Job applications begin."],
      ].map(([p, d, w, m], i) => new TableRow({ children: [
        new TableCell({ borders: cellBorders, shading: { fill: i % 2 === 0 ? C.white : C.light2, type: ShadingType.CLEAR }, width: { size: 1000, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 120, right: 120 }, children: [new Paragraph({ children: [bold(`Phase ${p}`, C.teal)] })] }),
        new TableCell({ borders: cellBorders, shading: { fill: i % 2 === 0 ? C.white : C.light2, type: ShadingType.CLEAR }, width: { size: 1400, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 120, right: 120 }, children: [new Paragraph({ children: [run(d)] })] }),
        new TableCell({ borders: cellBorders, shading: { fill: i % 2 === 0 ? C.white : C.light2, type: ShadingType.CLEAR }, width: { size: 1400, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 120, right: 120 }, children: [new Paragraph({ children: [run(w)] })] }),
        new TableCell({ borders: cellBorders, shading: { fill: i % 2 === 0 ? C.white : C.light2, type: ShadingType.CLEAR }, width: { size: 5560, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 120, right: 120 }, children: [new Paragraph({ children: [run(m)] })] }),
      ]}))
    ]
  }),
  new Paragraph({ spacing: sp(100, 0), children: [] }),

  h2("3.3  Phase 1 — Basic Dual-Corpus RAG (Week 1)"),
  new Paragraph({ spacing: sp(80, 0), children: [] }),
  phaseCard(
    "1", "Week 1 · Days 1–7", "Basic Dual-Corpus RAG Chatbot",
    "Two working RAG pipelines (code + compliance) with a Streamlit UI and live deployment",
    [
      "Day 1–2: Project setup — GitHub repo, pyenv, virtual environment, requirements.txt. Install all Phase 1 dependencies. Configure .env with API keys.",
      "Day 2: Corpus preparation — collect sample data: 2–3 Python/JS open-source FinTech repos (e.g., ccxt, freqtrade) + 3–5 public compliance PDFs (PCI-DSS v4.0, SOX overview, sample SEC filing).",
      "Day 3: Code ingestion pipeline — tree-sitter AST parsing, function-level chunking, nomic-embed-code embeddings, store in Chroma namespace 'codebase'.",
      "Day 3–4: Compliance ingestion pipeline — PyMuPDF PDF parsing, section-level chunking, sentence-transformers embeddings, store in Chroma namespace 'compliance'.",
      "Day 4: Basic RAG chain — LangChain RetrievalQA chain with 'I don't know' fallback. Separate chains for each corpus.",
      "Day 5: Streamlit UI — dual-pane interface, corpus selector, source citation display, conversation history.",
      "Day 6: Basic query router — simple keyword-based routing (code keywords → codebase corpus, regulation keywords → compliance corpus).",
      "Day 7: Deploy to Streamlit Cloud. Test with 20 sample queries. Document results in Build Log.",
    ],
    ["LlamaIndex (ingestion)", "tree-sitter (AST parsing)", "Chroma (vector store)", "sentence-transformers", "nomic-embed-code (Ollama)", "LangChain RetrievalQA", "PyMuPDF", "Streamlit"],
    "Live Streamlit app deployed on Streamlit Cloud with public URL. Two working RAG pipelines. 20 test queries documented.",
    ["Retrieval top-5 precision: baseline measurement", "Answer latency: < 5s (no optimization yet)", "Both corpora indexed and queryable", "20 test queries logged with outputs"],
    C.navy
  ),
  new Paragraph({ spacing: sp(100, 0), children: [] }),

  h2("3.4  Phase 2 — Production-Grade RAG (Week 2)"),
  new Paragraph({ spacing: sp(80, 0), children: [] }),
  phaseCard(
    "2", "Week 2 · Days 8–14", "Production RAG with Hybrid Retrieval + Evaluation",
    "Measurably better retrieval, cross-corpus routing, RAGAS metrics established as baseline",
    [
      "Day 8: Implement BM25 retrieval (rank_bm25) for both corpora. Run A/B test: pure vector vs. BM25 vs. hybrid. Document precision improvement.",
      "Day 9: Integrate Cohere Rerank v3 as post-retrieval reranker. Compare top-5 results before and after reranking on 50 test queries. Measure faithfulness change.",
      "Day 10: RAGAS evaluation suite setup — generate synthetic question-answer pairs from both corpora. Run faithfulness, answer_relevancy, context_precision, context_recall. Record baseline scores.",
      "Day 10–11: Chunk optimization experiments — test 3 chunk sizes (256, 512, 1024 tokens) and 3 overlap settings. Use RAGAS context_recall to determine optimal configuration.",
      "Day 11–12: Improve query router — replace keyword-based with LLM-based classifier (GPT-4o-mini). Test routing accuracy on 50 labeled queries. Target: > 90% routing accuracy.",
      "Day 12–13: 'I don't know' calibration — implement confidence scoring. If max chunk similarity < threshold, return fallback instead of hallucinated answer. Tune threshold.",
      "Day 13–14: DeepEval hallucination test suite — write 20 adversarial queries designed to trigger hallucinations. Measure and document hallucination rate.",
    ],
    ["BM25 (rank_bm25)", "Cohere Rerank v3 API", "RAGAS evaluation framework", "DeepEval", "LLM-based query classifier", "Confidence scoring layer"],
    "Updated app with hybrid retrieval. RAGAS score dashboard embedded in Streamlit. Evaluation results documented in Build Log.",
    ["Hybrid retrieval precision: +20–35% vs. Phase 1", "RAGAS faithfulness: ≥ 88%", "Hallucination rate: < 8%", "Query routing accuracy: ≥ 90%", "Answer latency: < 3s"],
    C.teal
  ),
  new Paragraph({ spacing: sp(100, 0), children: [] }),

  h2("3.5  Phase 3 — Multi-Agent System with LangGraph (Week 3)"),
  new Paragraph({ spacing: sp(80, 0), children: [] }),
  phaseCard(
    "3", "Week 3 · Days 15–21", "LangGraph Multi-Agent Orchestration",
    "Full agent graph with specialized agents, tool use, memory, and LangSmith observability",
    [
      "Day 15: LangGraph architecture design — define agent graph nodes: QueryClassifier → [CodeAnalyzer | ComplianceMapper | HybridSynthesizer] → ResponseFormatter. Draw state schema.",
      "Day 15–16: Implement QueryClassifier node — LLM-based with structured output. Routes to CODE, COMPLIANCE, or HYBRID branch. Test with 50 labeled queries.",
      "Day 16–17: Implement CodeAnalyzer agent — retrieves from codebase corpus, performs AST-aware analysis, identifies affected functions, estimates change impact.",
      "Day 17: Implement ComplianceMapper agent — retrieves from compliance corpus, extracts specific requirements, maps to code-relevant actions.",
      "Day 18: Implement HybridSynthesizer agent — receives outputs from both CodeAnalyzer and ComplianceMapper, generates unified cross-corpus answer with source attribution from both corpora.",
      "Day 18–19: Add tool use — CodeAnalyzer gets a 'run_code_snippet' tool for executing small Python functions. ComplianceMapper gets a 'search_regulation_index' tool.",
      "Day 19: Implement conversation memory — LangGraph checkpointer with SQLite backend. Per-user conversation history. Test multi-turn queries.",
      "Day 20: LangSmith integration — configure tracing for all nodes. Verify traces appear in LangSmith dashboard. Add custom metadata (corpus used, confidence score).",
      "Day 21: Error recovery — add retry logic for LLM timeouts, fallback paths for retrieval failures. Test with deliberately broken inputs.",
    ],
    ["LangGraph 0.2.x", "LangSmith tracing", "SQLite checkpointer (memory)", "Custom tool definitions", "Structured output (Pydantic)", "Error recovery patterns"],
    "Full agent graph running locally. LangSmith showing all traces. Cross-corpus queries working end-to-end. Error recovery tested.",
    ["Cross-corpus answer faithfulness: ≥ 91%", "Agent routing accuracy: ≥ 93%", "Multi-turn context retention: ≥ 85%", "End-to-end latency: < 4s", "LangSmith traces: 100% of queries"],
    C.gold
  ),
  new Paragraph({ spacing: sp(100, 0), children: [] }),

  h2("3.6  Phase 4 — Full SaaS Deployment (Weeks 4–5)"),
  new Paragraph({ spacing: sp(80, 0), children: [] }),
  phaseCard(
    "4", "Weeks 4–5 · Days 22–35", "Production SaaS with FastAPI + Docker + Live Deploy",
    "Production-ready system with auth, API, Docker, live public URL, and analytics",
    [
      "Day 22–23: FastAPI backend — restructure from Streamlit-only to FastAPI + Streamlit. Endpoints: POST /query, POST /ingest, GET /health, GET /metrics. Pydantic models for all I/O.",
      "Day 24: Supabase setup — configure auth, PostgreSQL tables (users, query_logs, corpus_configs). JWT middleware in FastAPI.",
      "Day 25: GitHub OAuth connector — users connect their GitHub repos. GitPython clones and indexes private repos into user-specific Chroma namespaces.",
      "Day 26: Rate limiting — Redis (Upstash) rate limiter middleware. Free tier: 50 queries/day. Pro tier: unlimited. Enforce via JWT claims.",
      "Day 27: Conversation history persistence — store conversation turns in Supabase PostgreSQL. Restore context on session resume.",
      "Day 28: Docker setup — Dockerfile for FastAPI app + docker-compose.yml for local dev (FastAPI + Chroma + Redis). Test full stack locally.",
      "Day 29–30: Deploy to Render — push Docker image, configure environment variables, set up auto-deploy from GitHub main branch. Get public URL.",
      "Day 30–31: Analytics dashboard — PostHog for query volume tracking. Build admin view in Streamlit showing: queries/day, top query types, RAGAS scores over time, latency P50/P95.",
      "Day 32–33: Ollama privacy mode — add LOCAL_MODE flag. When enabled, replace all OpenAI calls with Ollama (llama3.2). Document setup instructions.",
      "Day 34–35: End-to-end testing, bug fixes, performance optimization. Run full RAGAS evaluation on deployed system.",
    ],
    ["FastAPI 0.115", "Supabase (auth + DB)", "Redis/Upstash (rate limit)", "Docker + Docker Compose", "GitHub OAuth (GitPython)", "PostHog analytics", "Render deployment", "Ollama local mode"],
    "Live public URL on Render. Full auth flow working. GitHub repo connector working. Analytics dashboard live. Docker image published.",
    ["System uptime: ≥ 99% over test week", "API response time P95: < 3s", "Faithfulness score (deployed): ≥ 92%", "Hallucination rate: < 5%", "End-to-end hybrid query latency: < 3s"],
    C.red
  ),

  pageBreak()
);

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 4: REPO STRUCTURE
// ═══════════════════════════════════════════════════════════════════════════
children.push(
  sectionHeader("04", "GitHub Repository Structure"),
  new Paragraph({ spacing: sp(200, 0), children: [] }),

  h2("4.1  Recommended Folder Structure"),
  para("The repository is structured so that each phase is traceable via git branches and tags, while the main branch always reflects the latest production state."),
  new Paragraph({ spacing: sp(80, 0), children: [] }),

  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [3200, 6160],
    rows: [
      new TableRow({ children: [
        new TableCell({ borders: cellBorders, shading: { fill: C.navy, type: ShadingType.CLEAR }, width: { size: 3200, type: WidthType.DXA }, margins: { top: 100, bottom: 100, left: 120, right: 120 }, children: [new Paragraph({ children: [new TextRun({ text: "Path", font: "Arial", size: 20, bold: true, color: C.white })] })] }),
        new TableCell({ borders: cellBorders, shading: { fill: C.navy, type: ShadingType.CLEAR }, width: { size: 6160, type: WidthType.DXA }, margins: { top: 100, bottom: 100, left: 120, right: 120 }, children: [new Paragraph({ children: [new TextRun({ text: "Purpose", font: "Arial", size: 20, bold: true, color: C.white })] })] }),
      ]}),
      ...([
        ["finops-sentinel/", "Root repository"],
        ["├── ingestion/", "All document + code ingestion pipelines"],
        ["│   ├── code_ingestor.py", "AST parsing + code embedding pipeline"],
        ["│   ├── compliance_ingestor.py", "PDF parsing + compliance embedding pipeline"],
        ["│   └── github_connector.py", "GitHub OAuth repo cloning + indexing"],
        ["├── retrieval/", "Retrieval components"],
        ["│   ├── hybrid_retriever.py", "BM25 + vector + reranker pipeline"],
        ["│   └── query_router.py", "LLM-based corpus classifier"],
        ["├── agents/", "LangGraph agent definitions"],
        ["│   ├── graph.py", "Main LangGraph state graph definition"],
        ["│   ├── code_analyzer.py", "Code analysis agent node"],
        ["│   ├── compliance_mapper.py", "Compliance retrieval agent node"],
        ["│   └── synthesizer.py", "Cross-corpus synthesis agent node"],
        ["├── api/", "FastAPI application"],
        ["│   ├── main.py", "FastAPI app entry point"],
        ["│   ├── routes/", "API route handlers"],
        ["│   └── middleware/", "Auth, rate limiting middleware"],
        ["├── evaluation/", "RAGAS + DeepEval test suites"],
        ["│   ├── ragas_eval.py", "RAGAS metric computation"],
        ["│   ├── deepeval_tests.py", "DeepEval hallucination tests"],
        ["│   └── test_datasets/", "Golden Q&A pairs for evaluation"],
        ["├── ui/", "Streamlit frontend"],
        ["│   └── app.py", "Main Streamlit application"],
        ["├── docker/", "Docker configuration"],
        ["│   ├── Dockerfile", "FastAPI app container"],
        ["│   └── docker-compose.yml", "Full local stack"],
        ["├── docs/", "Project documentation"],
        ["│   ├── BUILD_LOG.md", "Session-by-session build log (update always)"],
        ["│   ├── ARCHITECTURE.md", "System architecture diagram + explanation"],
        ["│   └── METRICS.md", "All benchmark results by phase"],
        ["├── tests/", "Unit and integration tests"],
        ["├── .env.example", "Environment variable template (never commit .env)"],
        ["├── requirements.txt", "Pinned Python dependencies"],
        ["└── README.md", "The killer README — this is your resume"],
      ]).map(([path, desc], i) => new TableRow({ children: [
        new TableCell({ borders: cellBorders, shading: { fill: i % 2 === 0 ? C.white : C.light2, type: ShadingType.CLEAR }, width: { size: 3200, type: WidthType.DXA }, margins: { top: 60, bottom: 60, left: 120, right: 120 }, children: [new Paragraph({ children: [new TextRun({ text: path, font: "Courier New", size: 18, color: C.teal })] })] }),
        new TableCell({ borders: cellBorders, shading: { fill: i % 2 === 0 ? C.white : C.light2, type: ShadingType.CLEAR }, width: { size: 6160, type: WidthType.DXA }, margins: { top: 60, bottom: 60, left: 120, right: 120 }, children: [new Paragraph({ children: [run(desc, { size: 20 })] })] }),
      ]}))
    ]
  }),
  new Paragraph({ spacing: sp(80, 0), children: [] }),

  h2("4.2  Git Branching Strategy"),
  infoTable([
    ["main", "Always deployable. Tagged at end of each phase: v0.1, v0.2, v0.3, v1.0"],
    ["phase/1-basic-rag", "Phase 1 development branch. Merged to main when phase complete."],
    ["phase/2-production-rag", "Phase 2 development branch."],
    ["phase/3-multi-agent", "Phase 3 development branch."],
    ["phase/4-saas-deploy", "Phase 4 development branch."],
    ["feature/*", "Individual feature branches (e.g., feature/cohere-reranker, feature/bm25-hybrid)"],
    ["eval/*", "Evaluation experiment branches (e.g., eval/chunk-size-512-vs-1024)"],
  ]),

  pageBreak()
);

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 5: BUILD LOG TEMPLATE
// ═══════════════════════════════════════════════════════════════════════════
children.push(
  sectionHeader("05", "Build Log Template & Protocol"),
  new Paragraph({ spacing: sp(200, 0), children: [] }),

  h2("5.1  Build Log Protocol"),
  callout("MANDATORY", "Update the Build Log after EVERY work session without exception. This log is evidence of your engineering process — it is as important as the code itself for interviews and portfolio reviews.", C.highlight, C.gold),
  new Paragraph({ spacing: sp(80, 0), children: [] }),
  para("The build log lives at docs/BUILD_LOG.md in the repository and is also maintained in this document (Section 6). Each entry follows the template below:"),
  new Paragraph({ spacing: sp(80, 0), children: [] }),

  h2("5.2  Session Log Entry Template"),
  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [2200, 7160],
    rows: [
      new TableRow({ children: [
        new TableCell({ columnSpan: 2, borders: { top: bdr(C.navy,8), bottom: bdr(), left: bdr(C.navy,8), right: bdr(C.navy,8) }, shading: { fill: C.navy, type: ShadingType.CLEAR }, margins: { top: 100, bottom: 100, left: 160, right: 160 }, children: [new Paragraph({ children: [new TextRun({ text: "SESSION LOG ENTRY TEMPLATE", font: "Arial", size: 20, bold: true, color: C.gold })] })] })
      ]}),
      ...[
        ["Date & Time", "[DATE] — [START TIME] to [END TIME] — Total: [X hours]"],
        ["Phase / Branch", "Phase [N] — branch: [branch-name]"],
        ["Session Goal", "What did you set out to accomplish in this session?"],
        ["Work Completed", "Bullet list of every meaningful thing completed"],
        ["Decisions Made", "Architecture or tech choices made and WHY — this is gold for interviews"],
        ["Errors Encountered", "Every error, the full message, what caused it, and the exact fix"],
        ["Experiments Run", "Any A/B tests or metric experiments with results"],
        ["Current Metrics", "Latest RAGAS / DeepEval scores after this session's changes"],
        ["Next Session Goal", "Specific tasks for next session — be precise, not vague"],
        ["Blockers", "Anything blocking progress and the plan to resolve it"],
        ["Notes / Insights", "Any technical insights, interesting findings, or ideas for improvement"],
      ].map(([f, d], i) => new TableRow({ children: [
        new TableCell({ borders: cellBorders, shading: { fill: i % 2 === 0 ? C.light : "E8F0F5", type: ShadingType.CLEAR }, width: { size: 2200, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 120, right: 120 }, children: [new Paragraph({ children: [bold(f)] })] }),
        new TableCell({ borders: cellBorders, shading: { fill: C.white, type: ShadingType.CLEAR }, width: { size: 7160, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 120, right: 120 }, children: [new Paragraph({ children: [run(d, { color: C.muted, italics: true })] })] }),
      ]}))
    ]
  }),

  pageBreak()
);

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 6: METRICS & SUCCESS CRITERIA
// ═══════════════════════════════════════════════════════════════════════════
children.push(
  sectionHeader("06", "Metrics, Success Criteria & Portfolio Targets"),
  new Paragraph({ spacing: sp(200, 0), children: [] }),

  h2("6.1  Production Metrics Dashboard (Target Values)"),
  para("These are the numbers you will put on your resume, LinkedIn, and README. Every metric must be reproducible from the evaluation scripts in the /evaluation folder."),
  new Paragraph({ spacing: sp(80, 0), children: [] }),

  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [2800, 1600, 1600, 1600, 1760],
    rows: [
      new TableRow({ children: [
        ...["Metric", "Phase 1 Baseline", "Phase 2 Target", "Phase 3 Target", "Final Target"].map((t, i) => new TableCell({
          borders: cellBorders, shading: { fill: C.navy, type: ShadingType.CLEAR },
          width: { size: [2800,1600,1600,1600,1760][i], type: WidthType.DXA },
          margins: { top: 100, bottom: 100, left: 120, right: 120 },
          children: [new Paragraph({ children: [new TextRun({ text: t, font: "Arial", size: 19, bold: true, color: C.white })] })]
        }))
      ]}),
      ...([
        ["RAGAS Faithfulness", "Measure only", "≥ 88%", "≥ 91%", "≥ 93%"],
        ["RAGAS Answer Relevancy", "Measure only", "≥ 84%", "≥ 88%", "≥ 90%"],
        ["Hallucination Rate (DeepEval)", "Measure only", "< 8%", "< 6%", "< 4%"],
        ["Context Precision (top-5)", "Measure only", "≥ 0.82", "≥ 0.87", "≥ 0.90"],
        ["Hybrid vs. Vector Precision Gain", "Baseline", "+ ≥ 20%", "+ ≥ 28%", "+ ≥ 30%"],
        ["Query Routing Accuracy", "N/A", "≥ 90%", "≥ 93%", "≥ 95%"],
        ["Cross-Corpus Synthesis Faithfulness", "N/A", "N/A", "≥ 89%", "≥ 92%"],
        ["End-to-End Latency (P50)", "< 5s", "< 3s", "< 3s", "< 2.5s"],
        ["End-to-End Latency (P95)", "< 10s", "< 5s", "< 5s", "< 4s"],
        ["API Uptime (deployed)", "N/A", "N/A", "N/A", "≥ 99%"],
      ]).map(([m, p1, p2, p3, final], i) => new TableRow({ children: [
        new TableCell({ borders: cellBorders, shading: { fill: i % 2 === 0 ? C.white : C.light2, type: ShadingType.CLEAR }, width: { size: 2800, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 120, right: 120 }, children: [new Paragraph({ children: [bold(m, C.navy)] })] }),
        ...[p1, p2, p3, final].map((v, j) => new TableCell({ borders: cellBorders, shading: { fill: i % 2 === 0 ? C.white : C.light2, type: ShadingType.CLEAR }, width: { size: [1600,1600,1600,1760][j], type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 120, right: 120 }, children: [new Paragraph({ children: [run(v, { size: 20, color: j === 3 ? C.green : "333333", bold: j === 3 })] })] }))
      ]}))
    ]
  }),
  new Paragraph({ spacing: sp(80, 0), children: [] }),

  h2("6.2  Skills Mastered → Direct Job Requirement Mapping"),
  infoTable([
    ["Dual-corpus RAG with namespace separation", "Directly maps to: 'Design and implement RAG pipelines for enterprise knowledge bases' — seen in 80% of AI Engineer JDs"],
    ["Hybrid BM25 + vector retrieval", "Directly maps to: 'Improve retrieval quality using advanced search strategies' — distinguishes senior from junior candidates"],
    ["Cohere Rerank + reranking pipelines", "Directly maps to: 'Implement production RAG systems with evaluation' — reranking is a key production skill"],
    ["RAGAS + DeepEval evaluation", "Directly maps to: 'Design evaluation frameworks for LLM systems' — most critical skill gap in the market"],
    ["LangGraph multi-agent orchestration", "Directly maps to: 'Build agentic AI systems with multiple specialized agents' — the hottest skill in 2026"],
    ["AST-based code parsing (tree-sitter)", "Directly maps to: 'Build AI systems for developer productivity' — unique skill that few candidates demonstrate"],
    ["FastAPI async backend for AI", "Directly maps to: 'Deploy LLM applications to production' — required for every production AI role"],
    ["Docker + cloud deployment", "Directly maps to: 'Containerize and deploy AI systems' — table stakes for any engineering role"],
    ["LangSmith observability", "Directly maps to: 'Instrument AI systems for monitoring and debugging' — observability is increasingly required"],
    ["Cross-corpus reasoning (novel)", "Directly maps to: 'Solve complex multi-domain reasoning problems' — your unique differentiator, not seen in most portfolios"],
  ]),

  pageBreak()
);

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 7: LIVE BUILD LOG (starts empty, to be filled)
// ═══════════════════════════════════════════════════════════════════════════
children.push(
  sectionHeader("07", "Live Build Log — Updated Each Session"),
  new Paragraph({ spacing: sp(200, 0), children: [] }),

  callout("INSTRUCTION", "This section is your living record of the build. Copy the Session Log Entry Template from Section 5.2 and paste a new entry here after every work session. Do not skip sessions — even a 30-minute session should be logged.", C.highlight, C.gold),
  new Paragraph({ spacing: sp(100, 0), children: [] }),

  h2("Session 001 — [Fill After First Work Session]"),
  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [2200, 7160],
    rows: [
      ...[
        ["Date & Time", ""],
        ["Phase / Branch", ""],
        ["Session Goal", ""],
        ["Work Completed", ""],
        ["Decisions Made", ""],
        ["Errors Encountered", ""],
        ["Current Metrics", ""],
        ["Next Session Goal", ""],
      ].map(([f, d], i) => new TableRow({ children: [
        new TableCell({ borders: cellBorders, shading: { fill: i % 2 === 0 ? C.light : "E8F0F5", type: ShadingType.CLEAR }, width: { size: 2200, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 120, right: 120 }, children: [new Paragraph({ children: [bold(f)] })] }),
        new TableCell({ borders: cellBorders, shading: { fill: C.white, type: ShadingType.CLEAR }, width: { size: 7160, type: WidthType.DXA }, margins: { top: 100, bottom: 100, left: 120, right: 120 }, children: [new Paragraph({ children: [run("")] })] }),
      ]}))
    ]
  }),

  new Paragraph({ spacing: sp(200, 0), children: [] }),
  para([run("[ Additional sessions will be added here as the project progresses — each session gets its own table entry using the template above ]", { color: C.muted, italics: true })]),

  pageBreak()
);

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 8: INTERVIEW PREP
// ═══════════════════════════════════════════════════════════════════════════
children.push(
  sectionHeader("08", "Interview Preparation — Questions & Answers"),
  new Paragraph({ spacing: sp(200, 0), children: [] }),
  para("For every interview about this project, you will face these questions. Prepare your answers before the interview — anchor every answer to specific metrics and code decisions."),
  new Paragraph({ spacing: sp(80, 0), children: [] }),

  ...[
    ["Why dual-corpus RAG instead of a single unified corpus?", "A unified corpus mixes code and text, which confuses embedding models because code and natural language have fundamentally different semantic spaces. Code-specific models (nomic-embed-code) dramatically outperform general models on code retrieval. Separating corpora with namespaces gives us best-in-class retrieval for each domain. Our evaluation showed X% precision improvement with separated corpora vs. unified."],
    ["How did you handle the 'I don't know' problem?", "We implemented confidence-based fallback: compute the maximum cosine similarity across the top-retrieved chunks. If max similarity falls below a tuned threshold, we return a fallback response instead of generating an answer. We tuned the threshold using a held-out test set of unanswerable questions. This reduced hallucination rate from [X]% to [Y]%."],
    ["Why LangGraph over CrewAI or AutoGen?", "LangGraph gives us explicit control over the agent state machine as a directed graph. We can define exactly when agents hand off to each other, implement cycles and retries, and use checkpointers for conversation memory. AutoGen's actor model and CrewAI's role-based approach are harder to debug and less deterministic. LangSmith integration with LangGraph is also native and excellent for observability."],
    ["How did you evaluate the system objectively?", "We used RAGAS for retrieval quality (faithfulness, context precision, answer relevancy) and DeepEval for hallucination detection and adversarial testing. We generated synthetic evaluation datasets from both corpora using GPT-4o, then ran evaluations after every major change. This gave us a reproducible benchmark. The full evaluation suite is in the /evaluation folder and can be run with a single command."],
    ["What was the hardest technical challenge?", "Cross-corpus synthesis for HYBRID queries. When CodeAnalyzer and ComplianceMapper return independently retrieved contexts, the Synthesizer agent must merge them into a coherent answer without losing source attribution or introducing hallucinations. We iterated through 4 prompt designs before reaching a faithfulness score of ≥ 91% on hybrid queries. The key insight was explicitly structuring the synthesis prompt to require citing the source corpus for every claim."],
  ].flatMap(([q, a]) => [
    new Paragraph({ spacing: sp(100, 60), children: [bold(`Q: ${q}`, C.navy)] }),
    new Paragraph({ spacing: sp(0, 120), border: { left: { style: BorderStyle.SINGLE, size: 6, color: C.teal, space: 8 } }, indent: { left: 200 }, children: [run(a, { italics: true })] }),
  ]),

  pageBreak()
);

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 9: BONUS FEATURES & FUTURE ROADMAP
// ═══════════════════════════════════════════════════════════════════════════
children.push(
  sectionHeader("09", "Bonus Features & Future Roadmap"),
  new Paragraph({ spacing: sp(200, 0), children: [] }),

  h2("9.1  Bonus Twist — Dependency Impact Propagation Engine"),
  para("This is the single feature that elevates FinOps Sentinel from impressive portfolio project to genuinely novel system. Implement after Phase 4 if time permits, or describe as 'roadmap' in interviews."),
  new Paragraph({ spacing: sp(80, 0), children: [] }),
  callout("FEATURE", "When a developer changes a function, FinOps Sentinel automatically: (1) traces all downstream callers using the code graph, (2) checks if any affected code paths touch compliance-sensitive operations (payment processing, data encryption, audit logging), (3) retrieves the relevant compliance requirements, (4) generates a structured change impact report with compliance risk score. This is a full end-to-end agentic loop.", C.light, C.teal),
  new Paragraph({ spacing: sp(80, 0), children: [] }),

  h2("9.2  Future Roadmap (Post-Portfolio)"),
  infoTable([
    ["GraphRAG for Code Dependencies", "Build a knowledge graph (Neo4j or NetworkX) of function call relationships. Enable multi-hop queries: 'Which functions would fail if this API changes?' This is state-of-the-art and essentially unseen in portfolios."],
    ["CI/CD GitHub Action Integration", "GitHub Action that automatically runs FinOps Sentinel compliance check on every PR that touches compliance-sensitive code paths. Alert engineers in PR comments."],
    ["Multi-Language Code Support", "Extend tree-sitter parsing to Java, TypeScript, Go, C++ — languages used at banks and trading firms. Currently Python/JavaScript only."],
    ["Regulation Version Diffing", "When a regulation is updated (e.g., PCI-DSS v4.0 → v4.1), automatically identify which compliance requirements changed and which code sections are affected."],
    ["SOC 2 Compliance Path", "For enterprise sales: implement audit logging, data residency options, and access controls required for SOC 2 Type II certification."],
  ]),

  pageBreak()
);

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 10: ETHICS — WILL THIS HARM JOBS?
// ═══════════════════════════════════════════════════════════════════════════
children.push(
  sectionHeader("10", "Ethics & Impact — Will FinOps Sentinel Harm Jobs?"),
  new Paragraph({ spacing: sp(200, 0), children: [] }),

  callout("WHY THIS SECTION EXISTS", "You will be asked this question in enterprise sales conversations, investor pitches, and technical interviews. Having a clear, evidence-based, honest answer is not just ethically important — it is professionally essential. Document your position now, before you build.", C.highlight, C.gold),
  new Paragraph({ spacing: sp(100, 0), children: [] }),

  h2("10.1  The Direct Answer"),
  para([
    bold("No — FinOps Sentinel is an augmentation tool, not a replacement tool. "),
    run("The distinction is not semantic. It is architectural. The system is specifically designed to eliminate low-value, repetitive cognitive work — document searching, grep-based code hunting, manual cross-referencing — while leaving all judgment, accountability, decision-making, and creative work firmly with human engineers and compliance professionals.")
  ]),
  new Paragraph({ spacing: sp(80, 0), children: [] }),

  h2("10.2  What FinOps Sentinel Cannot Do (By Design)"),
  para("These are not current limitations waiting to be fixed in a future version. They are fundamental boundaries of the system's purpose:"),
  new Paragraph({ spacing: sp(60, 0), children: [] }),

  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [4680, 4680],
    rows: [
      new TableRow({ children: [
        new TableCell({ borders: cellBorders, shading: { fill: C.navy, type: ShadingType.CLEAR }, width: { size: 4680, type: WidthType.DXA }, margins: { top: 100, bottom: 100, left: 160, right: 160 },
          children: [new Paragraph({ children: [new TextRun({ text: "What FinOps Sentinel CANNOT do", font: "Arial", size: 20, bold: true, color: C.white })] })] }),
        new TableCell({ borders: cellBorders, shading: { fill: C.teal, type: ShadingType.CLEAR }, width: { size: 4680, type: WidthType.DXA }, margins: { top: 100, bottom: 100, left: 160, right: 160 },
          children: [new Paragraph({ children: [new TextRun({ text: "Who still does this (and always will)", font: "Arial", size: 20, bold: true, color: C.white })] })] }),
      ]}),
      ...([
        ["Make architectural decisions", "Senior engineers who understand business context, technical debt history, and team capabilities"],
        ["Interpret novel regulatory situations", "Compliance officers and legal counsel who hold professional accountability and regulatory relationships"],
        ["Take legal or regulatory accountability", "Licensed professionals — no AI system can hold regulatory liability"],
        ["Understand unstated business context", "Product managers and domain experts who know why the system was built this way"],
        ["Negotiate with auditors or regulators", "Compliance leads, CTOs, and legal teams in direct regulatory relationships"],
        ["Handle ambiguous, first-time scenarios", "Experienced engineers who have lived through similar situations and apply judgment"],
        ["Replace institutional knowledge", "Long-tenured engineers who understand organizational context, past decisions, and cultural constraints"],
        ["Make hiring, prioritization, or strategy decisions", "Engineering managers, CTOs, and executives"],
      ]).map(([cant, who], i) => new TableRow({ children: [
        new TableCell({ borders: cellBorders, shading: { fill: i%2===0?C.white:C.light2, type: ShadingType.CLEAR }, width: { size: 4680, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 160, right: 160 },
          children: [new Paragraph({ children: [run(cant, { color: C.red })] })] }),
        new TableCell({ borders: cellBorders, shading: { fill: i%2===0?C.white:C.light2, type: ShadingType.CLEAR }, width: { size: 4680, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 160, right: 160 },
          children: [new Paragraph({ children: [run(who, { color: C.green })] })] }),
      ]}))
    ]
  }),
  new Paragraph({ spacing: sp(100, 0), children: [] }),

  h2("10.3  What FinOps Sentinel Actually Does to Jobs"),
  para("The honest answer is nuanced and supported by historical precedent with every major productivity tool:"),
  new Paragraph({ spacing: sp(80, 0), children: [] }),

  infoTable([
    ["Shifts work upward in value", "Engineers currently spend significant time on manual compliance cross-referencing and code archaeology. FinOps Sentinel eliminates these tasks, freeing the same engineers to do architecture, system design, and complex problem-solving — higher-value, higher-satisfaction work. This is not job loss. It is job improvement."],
    ["Accelerates junior engineer productivity", "New engineers currently take 3–6 months to become productive in legacy financial codebases. FinOps Sentinel compresses this to weeks. This does not eliminate junior roles — it makes junior engineers more capable sooner, which is good for both the engineer and the organisation."],
    ["Enables team growth without proportional headcount", "A 10-person compliance engineering team using FinOps Sentinel can handle the workload previously requiring 13–15 people. In a growing regulatory environment, this means the same team handles new compliance requirements without burning out — not that people are fired."],
    ["Creates new roles it did not exist to fill", "Deploying and maintaining an AI system like FinOps Sentinel requires AI Engineers, prompt engineers, evaluation specialists, and AI product managers. These are new jobs that did not exist before the tool. The tool creates demand for the exact skills you are building right now."],
    ["Historical precedent is clear", "IDEs did not eliminate programmers — the number of software engineers grew 10x after IDE adoption. Google did not eliminate researchers — academic research output increased after search engines. Excel did not eliminate accountants — the accounting profession grew after spreadsheet adoption. Productivity tools consistently expand the scope of what is possible, growing the workforce rather than shrinking it."],
  ]),
  new Paragraph({ spacing: sp(80, 0), children: [] }),

  h2("10.4  The Enterprise Reality in 2026"),
  para([
    run("Financial companies are not shrinking their engineering teams. They are "),
    bold("growing them"), run(" — precisely because regulatory complexity is expanding faster than teams can scale. DORA (effective January 2025), the EU AI Act, updated SEC cybersecurity disclosure rules, and Basel IV all require new technical capabilities. The compliance surface area is larger in 2026 than it has ever been.")
  ]),
  para("FinOps Sentinel helps existing teams handle this expanding surface area without burning out. It is a force multiplier applied to a workload that is growing, not a replacement applied to a workload that is shrinking."),
  new Paragraph({ spacing: sp(80, 0), children: [] }),

  callout("INTERVIEW ANSWER", "If asked in an interview: I built a force multiplier, not a replacement. The regulatory surface area in financial services is expanding faster than any team can manually track. FinOps Sentinel helps the same engineers handle more — which means companies grow without proportionally growing headcount, and engineers spend their time on judgment and architecture rather than document search. The tool creates more demand for skilled engineers, not less.", C.light, C.teal),
  new Paragraph({ spacing: sp(80, 0), children: [] }),

  h2("10.5  Ethical Commitments Built Into the System"),
  para("These are design decisions, not marketing claims. They should be documented in the README and enforced in code:"),
  bullet([bold("Source attribution is mandatory: "), run("Every answer includes the exact source document and section it was retrieved from. Engineers and compliance officers can always verify the reasoning. No black-box answers.")]),
  bullet([bold("Confidence scoring is visible: "), run("Low-confidence answers are flagged explicitly. The system says 'I don't know' when retrieval similarity falls below threshold rather than generating a plausible-sounding hallucination.")]),
  bullet([bold("Human sign-off is required: "), run("The system generates recommendations and analysis. It does not take action. No compliance change, code refactor, or regulatory interpretation is implemented without a human approving it.")]),
  bullet([bold("Local / private mode is first-class: "), run("Enterprise on-prem deployment with Ollama means sensitive code and financial data never leaves the organisation's infrastructure. Data sovereignty is a feature, not an afterthought.")]),
  bullet([bold("Audit logs are immutable: "), run("Every query, every answer, every source retrieved is logged. Organisations can audit what the system said and on what basis. This supports, rather than undermines, regulatory accountability.")]),

  pageBreak()
);

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 11: AI TOOLS & DEV ENVIRONMENT
// ═══════════════════════════════════════════════════════════════════════════
children.push(
  sectionHeader("11", "AI Tools, IDE Setup & Development Workflow"),
  new Paragraph({ spacing: sp(200, 0), children: [] }),

  para("You are building an AI system — use AI aggressively to build it. This section documents the exact toolchain that will give you a 5-10x speed advantage over candidates building this the traditional way. Each tool has a specific role. Using the wrong tool for the wrong task is as inefficient as using no AI at all."),
  new Paragraph({ spacing: sp(80, 0), children: [] }),

  h2("11.1  The Core Principle — Right Tool, Right Task"),
  callout("RULE", "AI coding tools are not interchangeable. Claude Code is not Copilot. Cursor is not ChatGPT. Each tool has a specific cognitive task it outperforms others at. The developers who go fastest in 2026 are not the ones using the most AI — they are the ones using the right AI for each specific task.", C.highlight, C.gold),
  new Paragraph({ spacing: sp(100, 0), children: [] }),

  h2("11.2  Tier 1 — Use These Every Single Day"),
  new Paragraph({ spacing: sp(80, 0), children: [] }),

  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [1800, 1400, 2200, 3960],
    rows: [
      new TableRow({ children: [
        ...["Tool", "Cost", "Best For", "When to Use on This Project"].map((t, i) => new TableCell({
          borders: cellBorders, shading: { fill: C.navy, type: ShadingType.CLEAR },
          width: { size: [1800,1400,2200,3960][i], type: WidthType.DXA },
          margins: { top: 100, bottom: 100, left: 120, right: 120 },
          children: [new Paragraph({ children: [new TextRun({ text: t, font: "Arial", size: 19, bold: true, color: C.white })] })]
        }))
      ]}),
      ...([
        ["Claude Code", "Usage-based (~$20-50/mo typical)", "Complex multi-file reasoning, architecture, LangGraph logic", "Architecture decisions. Designing agent graph nodes. Debugging multi-hop retrieval failures. Understanding why RAGAS scores dropped. Reviewing your entire pipeline at once. Writing the synthesis agent prompt."],
        ["Cursor IDE", "Free / $20 Pro/mo", "Multi-file editing, Composer for large refactors, inline chat", "Day-to-day coding. Use Composer to implement an entire new module from a description. Use inline chat to refactor a function. Fastest tool for implementing decisions you have already made architecturally."],
        ["GitHub Copilot", "Free (students) / $10/mo", "Inline autocomplete, boilerplate, repetitive patterns", "Writing FastAPI route handlers, Pydantic models, pytest boilerplate, repetitive LangGraph node scaffolding. Unbeatable at predicting what you are about to type for standard patterns."],
      ]).map(([tool, cost, best, when], i) => new TableRow({ children: [
        new TableCell({ borders: cellBorders, shading: { fill: i%2===0?C.white:C.light2, type: ShadingType.CLEAR }, width: { size: 1800, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 120, right: 120 }, children: [new Paragraph({ children: [bold(tool, C.teal)] })] }),
        new TableCell({ borders: cellBorders, shading: { fill: i%2===0?C.white:C.light2, type: ShadingType.CLEAR }, width: { size: 1400, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 120, right: 120 }, children: [new Paragraph({ children: [run(cost, { size: 20 })] })] }),
        new TableCell({ borders: cellBorders, shading: { fill: i%2===0?C.white:C.light2, type: ShadingType.CLEAR }, width: { size: 2200, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 120, right: 120 }, children: [new Paragraph({ children: [run(best, { size: 20 })] })] }),
        new TableCell({ borders: cellBorders, shading: { fill: i%2===0?C.white:C.light2, type: ShadingType.CLEAR }, width: { size: 3960, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 120, right: 120 }, children: [new Paragraph({ children: [run(when, { size: 20 })] })] }),
      ]}))
    ]
  }),
  new Paragraph({ spacing: sp(100, 0), children: [] }),

  h2("11.3  Tier 2 — Use for Specific Tasks"),
  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [1800, 1400, 2200, 3960],
    rows: [
      new TableRow({ children: [
        ...["Tool", "Cost", "Strength", "Specific Use Case on This Project"].map((t, i) => new TableCell({
          borders: cellBorders, shading: { fill: C.teal, type: ShadingType.CLEAR },
          width: { size: [1800,1400,2200,3960][i], type: WidthType.DXA },
          margins: { top: 100, bottom: 100, left: 120, right: 120 },
          children: [new Paragraph({ children: [new TextRun({ text: t, font: "Arial", size: 19, bold: true, color: C.white })] })]
        }))
      ]}),
      ...([
        ["Perplexity AI", "Free / $20 Pro/mo", "Research with live citations", "Tech decisions with sourced answers. Use before making any major architecture choice. Faster and more reliable than Google for technical decisions."],
        ["ChatGPT GPT-4o", "Free / $20/mo", "Quick explanations, error messages", "Paste a Python traceback, get a fix in 10 seconds. Good for short, self-contained debugging. Not as strong as Claude for long-context reasoning."],
        ["Gemini 1.5 Pro", "Free (large limits)", "1M token context window", "Load your ENTIRE codebase or a full 360-page regulatory PDF into one context. Ask what sections are relevant to a specific code module — impossible with other models."],
        ["Grok (xAI)", "Free via X Premium", "Real-time web data", "Check current GitHub issues on LangChain/LangGraph when you hit a bug that might be a known library issue. Faster than searching GitHub manually."],
        ["Aider", "Free (OSS)", "Terminal AI coding with git", "Automated git commits with AI-generated code. Good for implementing a well-defined feature from the terminal with automatic git tracking."],
        ["Codeium", "Free", "Copilot alternative", "If GitHub Copilot cost is a concern, Codeium gives similar autocomplete quality on a generous free tier. Use as a direct Copilot substitute."],
      ]).map(([tool, cost, strength, use], i) => new TableRow({ children: [
        new TableCell({ borders: cellBorders, shading: { fill: i%2===0?C.white:C.light2, type: ShadingType.CLEAR }, width: { size: 1800, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 120, right: 120 }, children: [new Paragraph({ children: [bold(tool, C.teal)] })] }),
        new TableCell({ borders: cellBorders, shading: { fill: i%2===0?C.white:C.light2, type: ShadingType.CLEAR }, width: { size: 1400, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 120, right: 120 }, children: [new Paragraph({ children: [run(cost, { size: 20 })] })] }),
        new TableCell({ borders: cellBorders, shading: { fill: i%2===0?C.white:C.light2, type: ShadingType.CLEAR }, width: { size: 2200, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 120, right: 120 }, children: [new Paragraph({ children: [run(strength, { size: 20 })] })] }),
        new TableCell({ borders: cellBorders, shading: { fill: i%2===0?C.white:C.light2, type: ShadingType.CLEAR }, width: { size: 3960, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 120, right: 120 }, children: [new Paragraph({ children: [run(use, { size: 20 })] })] }),
      ]}))
    ]
  }),
  new Paragraph({ spacing: sp(100, 0), children: [] }),

  h2("11.4  The Recommended Daily Workflow"),
  para("This is the exact sequence to follow every work session to maximise speed without losing quality:"),
  new Paragraph({ spacing: sp(60, 0), children: [] }),

  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [700, 2100, 2160, 4400],
    rows: [
      new TableRow({ children: [
        ...["Step", "Activity", "Tool", "Details"].map((t, i) => new TableCell({
          borders: cellBorders, shading: { fill: C.navy, type: ShadingType.CLEAR },
          width: { size: [700,2100,2160,4400][i], type: WidthType.DXA },
          margins: { top: 100, bottom: 100, left: 120, right: 120 },
          children: [new Paragraph({ children: [new TextRun({ text: t, font: "Arial", size: 19, bold: true, color: C.white })] })]
        }))
      ]}),
      ...([
        ["01", "Plan the session", "Claude Code or pen + paper", "Read your build log from last session. Define exactly what you will build today. Never start coding without a clear goal — AI tools amplify both speed and aimlessness equally."],
        ["02", "Architecture questions", "Claude Code", "If unsure HOW to build something, ask Claude Code with full context: paste your existing code and the problem. Get a decision, then commit to it."],
        ["03", "Research tech choices", "Perplexity", "For new technology decisions, use Perplexity for cited, current answers before asking Claude. Both together is the strongest combination."],
        ["04", "Implement new modules", "Cursor Composer", "For new files or multi-file features: describe what you want in plain English, let Composer scaffold, then review and refine. Never accept output blindly."],
        ["05", "Inline coding", "Copilot or Cursor Tab", "For filling in function bodies, writing tests, repetitive patterns — let autocomplete do the typing. Your job is to review and direct, not type."],
        ["06", "Debug errors", "Claude Code", "For non-obvious errors: paste the full traceback and relevant code. For simple errors (typos, imports), fix them yourself — do not waste context on trivial issues."],
        ["07", "Evaluate and measure", "Your brain + RAGAS/DeepEval", "Run your eval suite. Interpret the numbers yourself. AI tools cannot tell you whether a 3% faithfulness improvement is worth 200ms extra latency — that is your judgment call."],
        ["08", "Update build log", "VS Code + your own words", "Write the session log entry in your own words. Do not use AI to write your build log — it is a record of your thinking, not a generated summary."],
      ]).map(([step, act, tool, detail], i) => new TableRow({ children: [
        new TableCell({ borders: cellBorders, shading: { fill: i%2===0?C.white:C.light2, type: ShadingType.CLEAR }, width: { size: 700, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 120, right: 120 }, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [bold(step, C.teal)] })] }),
        new TableCell({ borders: cellBorders, shading: { fill: i%2===0?C.white:C.light2, type: ShadingType.CLEAR }, width: { size: 2100, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 120, right: 120 }, children: [new Paragraph({ children: [bold(act)] })] }),
        new TableCell({ borders: cellBorders, shading: { fill: i%2===0?C.white:C.light2, type: ShadingType.CLEAR }, width: { size: 2160, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 120, right: 120 }, children: [new Paragraph({ children: [run(tool, { size: 20, color: C.teal })] })] }),
        new TableCell({ borders: cellBorders, shading: { fill: i%2===0?C.white:C.light2, type: ShadingType.CLEAR }, width: { size: 4400, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 120, right: 120 }, children: [new Paragraph({ children: [run(detail, { size: 20 })] })] }),
      ]}))
    ]
  }),
  new Paragraph({ spacing: sp(100, 0), children: [] }),

  h2("11.5  Prompting Strategy — Getting 10x Better Output from AI Tools"),
  para("The quality of AI output is determined almost entirely by the quality of your prompt. These patterns work specifically for building RAG and agent systems:"),
  new Paragraph({ spacing: sp(80, 0), children: [] }),

  infoTable([
    ["Always give full context", "Paste your existing code, your current architecture, and the specific problem. Never ask a decontextualised question like 'how do I use LangGraph?'. Instead: 'Here is my current graph.py [paste]. I need to add a retry node that fires when the compliance mapper returns empty context. How should I structure this?'"],
    ["State the constraint explicitly", "Always tell the AI what you cannot change: 'I cannot change the Chroma namespace structure because my ingestion scripts depend on it. Given that constraint, how do I add hybrid BM25 retrieval?'"],
    ["Ask for the why, not just the what", "After getting code: 'Explain why you chose this approach over the alternative. What are the trade-offs?' This forces understanding and gives you interview-ready answers about your own decisions."],
    ["Request structured outputs for evaluation", "When generating test data: 'Generate 20 question-answer pairs from this compliance document. Format as JSON with fields: question, ground_truth_answer, relevant_chunks. Make 5 of them unanswerable from the document to test the I-don't-know fallback.'"],
    ["Iterate on metrics, not feelings", "Never say 'the output seems wrong'. Say 'RAGAS faithfulness dropped from 88% to 81% after I changed chunk size from 512 to 256 tokens. Here is the eval output [paste]. What are the likely causes and which should I investigate first?'"],
    ["Weekly architecture reviews", "Once a week: paste your entire project structure and key files into Claude Code. Ask: What are the 3 biggest architectural risks in this system? What would a senior AI Engineer at a bank say about this design?"],
  ]),
  new Paragraph({ spacing: sp(80, 0), children: [] }),

  h2("11.6  VS Code Extensions — Complete Setup List"),
  infoTable([
    ["Python (Microsoft)", "Required. Core Python language support, IntelliSense, linting."],
    ["Pylance", "Required. Fast Python type checking. Catches type errors before runtime — critical when working with Pydantic models and typed LangGraph state schemas."],
    ["Ruff", "Recommended. Extremely fast Python linter and formatter. Replaces Black, Flake8, and isort in one tool with a single VS Code extension."],
    ["Docker (Microsoft)", "Required for Phase 4. Manage containers, view logs, debug Docker Compose from VS Code without leaving the editor."],
    ["GitLens", "Strongly recommended. See who wrote every line, visualise git history, compare branches. Invaluable for understanding your own project evolution across phases."],
    ["Thunder Client", "REST API testing inside VS Code. Test FastAPI endpoints without switching to Postman. Saves constant context-switching during Phase 4 development."],
    ["Todo Tree", "Highlights TODO, FIXME, and HACK comments across your codebase. Use TODO comments during fast development to track technical debt, then clear them before each phase commit."],
    ["Error Lens", "Shows errors and warnings inline, next to the code that causes them. Eliminates the need to hover over red underlines. Dramatically speeds up debugging feedback loops."],
  ]),
  new Paragraph({ spacing: sp(80, 0), children: [] }),

  h2("11.7  AI Tool Cost Management"),
  para("Building this project with AI tools aggressively should cost $30-80 per month in API and subscription fees. Manage costs intelligently:"),
  bullet([bold("Use GPT-4o-mini for 90% of LLM calls "), run("during development. Switch to GPT-4o only for final evaluation runs and complex synthesis. The quality difference is minimal for most tasks; the cost difference is 15x.")]),
  bullet([bold("Cache embeddings aggressively. "), run("Never re-embed the same document twice. Use Chroma persistent storage. During development, work with a small 10-document corpus subset and only run full ingestion when testing ingestion quality specifically.")]),
  bullet([bold("Use Ollama locally for routine testing. "), run("For checking that the pipeline runs and the UI displays correctly, use llama3.2 via Ollama. Zero API cost. Switch to OpenAI only for quality benchmarking and final evaluation runs.")]),
  bullet([bold("Set API spend alerts immediately. "), run("OpenAI, Cohere, and Anthropic all support hard spend limits. Set a $20/month development limit to prevent runaway costs from accidental infinite loops in agent code.")]),
  bullet([bold("LangSmith free tier is sufficient. "), run("5,000 traces per month covers all Phase 1 through 3 development. Only upgrade if you need more traces in Phase 4 when testing with real user traffic.")]),

  pageBreak()
);

// ═══════════════════════════════════════════════════════════════════════════
// SECTION 12: REAL DATASETS — BENCHMARKS & LEGAL STATUS
// ═══════════════════════════════════════════════════════════════════════════
children.push(
  sectionHeader("12", "Real Datasets — Generating Legitimate Metrics & Benchmarks"),
  new Paragraph({ spacing: sp(200, 0), children: [] }),

  callout("THE CORE ANSWER", "Yes — you can and should use real datasets. Every metric in this project can be generated from publicly available, legally clear sources. You do not need private enterprise data. The public sources available are richer, more impressive, and more verifiable than most internal enterprise data anyway.", C.light, C.teal),
  new Paragraph({ spacing: sp(100, 0), children: [] }),

  para([bold("Why real data matters for your portfolio: "), run("Any experienced interviewer or technical recruiter can tell the difference between metrics generated on toy data ('I made a 10-line Python file called bank.py') versus metrics generated on a real-world corpus. Saying 'evaluated on 150,000 lines of production-grade open-source FinTech code and 800 pages of actual PCI-DSS, DORA, and SEC regulatory documents' is a fundamentally different claim — and it is entirely achievable with publicly available sources.")]),
  new Paragraph({ spacing: sp(80, 0), children: [] }),

  h2("12.1  Corpus A — Compliance & Regulatory Documents"),
  para("This is the easiest corpus to populate with real data. Almost every financial regulation is public law or a publicly published standard — they are designed to be read by anyone who needs to comply with them. All sources below are free, legal to use, and carry zero intellectual property risk."),
  new Paragraph({ spacing: sp(80, 0), children: [] }),

  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [2000, 2200, 1400, 3760],
    rows: [
      new TableRow({ children: [
        ...["Document / Standard", "Source URL", "Size", "Why Include It"].map((t, i) => new TableCell({
          borders: cellBorders, shading: { fill: C.navy, type: ShadingType.CLEAR },
          width: { size: [2000,2200,1400,3760][i], type: WidthType.DXA },
          margins: { top: 100, bottom: 100, left: 120, right: 120 },
          children: [new Paragraph({ children: [new TextRun({ text: t, font: "Arial", size: 19, bold: true, color: C.white })] })]
        }))
      ]}),
      ...([
        ["PCI-DSS v4.0", "pcisecuritystandards.org (free registration)", "~360 pages", "The global payment card security standard. Directly maps to code in any payment processing system. Dense with technical requirements."],
        ["SOX — Sarbanes-Oxley Act", "congress.gov (public law)", "~66 pages", "US financial reporting law. Sections 302 and 404 directly require specific audit trail and internal control code behaviors."],
        ["DORA — EU Digital Operational Resilience Act", "eur-lex.europa.eu (public EU law)", "~140 pages", "Effective January 2025. Requires specific ICT risk management, incident reporting, and third-party oversight. Extremely current and relevant."],
        ["MiFID II — Markets in Financial Instruments Directive", "eur-lex.europa.eu (public EU law)", "~450 pages", "EU trading regulation. Requires specific algorithmic trading controls, best execution documentation, and transaction reporting code."],
        ["Basel III Framework", "bis.org (free PDF)", "~616 pages", "International banking capital requirements. Used by every major bank globally. Technical annex has highly code-relevant risk calculation requirements."],
        ["FINRA Rulebook", "finra.org (publicly accessible)", "~1,000+ pages", "US broker-dealer rules. The Rule 4370 Business Continuity sections directly require specific system architecture and failover code behaviors."],
        ["FCA Handbook (UK)", "handbook.fca.org.uk (public)", "Extensive", "UK financial conduct rules. SYSC (Senior Management Arrangements) chapters are highly relevant to FinTech engineering controls."],
        ["FFIEC IT Examination Handbooks", "ffiec.gov (free PDFs)", "~8 volumes", "US banking IT audit framework. The Architecture, Infrastructure & Operations handbook directly maps to infrastructure and code requirements."],
        ["SEC Regulation SCI", "sec.gov (public)", "~200 pages", "US systems compliance and integrity rules for trading platforms. Very specific technical requirements for system capacity, security, and backup."],
        ["NY DFS Part 500 Cybersecurity Regulation", "dfs.ny.gov (public)", "~30 pages", "New York State cybersecurity requirements for financial services. Requires specific encryption, access control, and audit logging code."],
      ]).map(([doc, src, size, why], i) => new TableRow({ children: [
        new TableCell({ borders: cellBorders, shading: { fill: i%2===0?C.white:C.light2, type: ShadingType.CLEAR }, width: { size: 2000, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 120, right: 120 }, children: [new Paragraph({ children: [bold(doc, C.teal)] })] }),
        new TableCell({ borders: cellBorders, shading: { fill: i%2===0?C.white:C.light2, type: ShadingType.CLEAR }, width: { size: 2200, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 120, right: 120 }, children: [new Paragraph({ children: [run(src, { size: 19, color: C.muted })] })] }),
        new TableCell({ borders: cellBorders, shading: { fill: i%2===0?C.white:C.light2, type: ShadingType.CLEAR }, width: { size: 1400, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 120, right: 120 }, children: [new Paragraph({ children: [run(size, { size: 19 })] })] }),
        new TableCell({ borders: cellBorders, shading: { fill: i%2===0?C.white:C.light2, type: ShadingType.CLEAR }, width: { size: 3760, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 120, right: 120 }, children: [new Paragraph({ children: [run(why, { size: 19 })] })] }),
      ]}))
    ]
  }),
  new Paragraph({ spacing: sp(80, 0), children: [] }),

  callout("PHASE 1 RECOMMENDATION", "Start with just 3 documents: PCI-DSS v4.0 + DORA + one SEC 10-K filing from a public company (e.g., JPMorgan Chase, available free on EDGAR). This gives you ~500 pages of real regulatory text — more than enough to build and evaluate Phase 1 and 2. Add more documents in later phases.", C.light, C.teal),
  new Paragraph({ spacing: sp(80, 0), children: [] }),

  h2("12.2  SEC EDGAR — Bulk Financial Filings"),
  para("The SEC's EDGAR system is one of the richest free financial document datasets in existence. Every public US company must file here. You have programmatic API access at zero cost."),
  new Paragraph({ spacing: sp(60, 0), children: [] }),

  infoTable([
    ["What is available", "Every 10-K (annual report), 10-Q (quarterly report), 8-K (material events), proxy statements, and hundreds of other filing types for every public US company going back to the 1990s. Hundreds of millions of documents total."],
    ["API access", "Free at data.sec.gov/submissions/. No API key required. Programmatic bulk download supported. The SEC explicitly encourages automated access for research and compliance purposes."],
    ["Best filings for your project", "10-K annual reports from financial companies: JPMorgan Chase, Goldman Sachs, Citigroup, Bank of America, Stripe (pre-IPO filings when available), PayPal, Square/Block. These contain risk factor sections, technology risk disclosures, and operational descriptions that create interesting cross-corpus queries."],
    ["Recommended starting set", "Download 10-K filings from 3 to 5 major banks for the last 2 years. This gives you ~2,000 pages of real financial disclosures with natural language descriptions of technology risks and compliance frameworks — ideal for testing cross-corpus compliance mapping."],
    ["Legal status", "100% public domain. The SEC explicitly states that EDGAR content is available for unrestricted use. You can use it commercially, publish benchmarks derived from it, and include it in any portfolio."],
  ]),
  new Paragraph({ spacing: sp(100, 0), children: [] }),

  h2("12.3  Corpus B — Open Source FinTech Codebases"),
  para("For the code corpus, open-source FinTech repositories give you real, production-quality code at the scale needed to make retrieval interesting and metrics meaningful. These are all actively maintained by real engineering teams at real companies."),
  new Paragraph({ spacing: sp(80, 0), children: [] }),

  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [1700, 1000, 1200, 1600, 3860],
    rows: [
      new TableRow({ children: [
        ...["Repository", "Stars", "License", "Lines of Code", "Why It Is Perfect for This Project"].map((t, i) => new TableCell({
          borders: cellBorders, shading: { fill: C.navy, type: ShadingType.CLEAR },
          width: { size: [1700,1000,1200,1600,3860][i], type: WidthType.DXA },
          margins: { top: 100, bottom: 100, left: 120, right: 120 },
          children: [new Paragraph({ children: [new TextRun({ text: t, font: "Arial", size: 18, bold: true, color: C.white })] })]
        }))
      ]}),
      ...([
        ["ccxt", "35,000+", "MIT", "~180,000", "Cryptocurrency exchange trading library. Supports 100+ exchanges. Real financial code with authentication, rate limiting, order management, and error handling patterns. Ideal for compliance mapping (authentication = PCI-DSS)."],
        ["freqtrade", "28,000+", "GPL-3.0", "~95,000", "Open source crypto trading bot. Python. Complex strategy engine, risk management, backtesting framework. Real algorithmic trading code — perfect for MiFID II algorithmic trading control requirements."],
        ["OpenBB Terminal", "26,000+", "MIT", "~210,000", "Open source Bloomberg Terminal alternative. Financial data integration, charting, portfolio management. Demonstrates real-world financial data handling at scale."],
        ["zipline-reloaded", "3,000+", "Apache 2.0", "~70,000", "Algorithmic trading library, fork of Quantopian's zipline used by actual hedge funds. Has real risk management and position management code that maps directly to Basel capital requirement calculations."],
        ["QuantLib (Python)", "4,500+", "Modified BSD", "~50,000 Python", "Professional quantitative finance library. Used by real banks and asset managers. Pricing models, yield curves, risk metrics — the most technically sophisticated code in this list."],
        ["Backtrader", "13,000+", "GPL-3.0", "~45,000", "Python backtesting framework. Real broker integration patterns, order management logic, and trade lifecycle management. Useful for testing code retrieval on financial workflow patterns."],
        ["JPMorgan Perspective", "7,500+", "Apache 2.0", "~60,000", "Actually open-sourced by JPMorgan Chase. Real production financial visualization code from a Tier-1 bank. Having a major bank's actual code in your corpus is a compelling portfolio story."],
        ["Goldman Sachs Legend", "4,000+", "Apache 2.0", "~500,000+", "Open-sourced by Goldman Sachs. Data management and modeling platform. Extremely large, complex codebase — demonstrates your system can handle enterprise-scale code at real bank complexity."],
      ]).map(([repo, stars, lic, loc, why], i) => new TableRow({ children: [
        new TableCell({ borders: cellBorders, shading: { fill: i%2===0?C.white:C.light2, type: ShadingType.CLEAR }, width: { size: 1700, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 120, right: 120 }, children: [new Paragraph({ children: [bold(repo, C.teal)] })] }),
        new TableCell({ borders: cellBorders, shading: { fill: i%2===0?C.white:C.light2, type: ShadingType.CLEAR }, width: { size: 1000, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 120, right: 120 }, children: [new Paragraph({ children: [run(stars, { size: 18 })] })] }),
        new TableCell({ borders: cellBorders, shading: { fill: i%2===0?C.white:C.light2, type: ShadingType.CLEAR }, width: { size: 1200, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 120, right: 120 }, children: [new Paragraph({ children: [run(lic, { size: 18 })] })] }),
        new TableCell({ borders: cellBorders, shading: { fill: i%2===0?C.white:C.light2, type: ShadingType.CLEAR }, width: { size: 1600, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 120, right: 120 }, children: [new Paragraph({ children: [run(loc, { size: 18 })] })] }),
        new TableCell({ borders: cellBorders, shading: { fill: i%2===0?C.white:C.light2, type: ShadingType.CLEAR }, width: { size: 3860, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 120, right: 120 }, children: [new Paragraph({ children: [run(why, { size: 18 })] })] }),
      ]}))
    ]
  }),
  new Paragraph({ spacing: sp(80, 0), children: [] }),

  callout("PHASE 1 RECOMMENDATION", "Start with ccxt + freqtrade only (~275,000 lines of code combined). This is already more than enough to make retrieval challenging and metrics meaningful. Add OpenBB and Goldman Sachs Legend in Phase 3 when your system can handle larger corpora. Never start with the full dataset — you will waste time on ingestion instead of building.", C.highlight, C.gold),
  new Paragraph({ spacing: sp(100, 0), children: [] }),

  h2("12.4  What You Must NOT Use — Legal Boundaries"),
  para("These boundaries are not optional. Violating them can have real legal consequences and will disqualify you from employment at any regulated financial institution if discovered."),
  new Paragraph({ spacing: sp(60, 0), children: [] }),

  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [2800, 1400, 5160],
    rows: [
      new TableRow({ children: [
        ...["Data Type", "Status", "Why and What to Do Instead"].map((t, i) => new TableCell({
          borders: cellBorders, shading: { fill: C.red, type: ShadingType.CLEAR },
          width: { size: [2800,1400,5160][i], type: WidthType.DXA },
          margins: { top: 100, bottom: 100, left: 120, right: 120 },
          children: [new Paragraph({ children: [new TextRun({ text: t, font: "Arial", size: 19, bold: true, color: C.white })] })]
        }))
      ]}),
      ...([
        ["Code from a previous or current employer", "NEVER USE", "Violates your employment agreement and potentially trade secret law regardless of whether you think it is harmless. Use open-source repos instead — they are richer and more impressive."],
        ["Internal company documents, wikis, or SOPs", "NEVER USE", "Same as above. Any internal document you accessed as an employee is covered by confidentiality obligations. Use public regulatory documents — they are better test material anyway."],
        ["Scraped financial news or proprietary research", "AVOID", "Bloomberg, Reuters, and most financial news services have Terms of Service that prohibit scraping. Use SEC EDGAR and publicly available regulatory text instead."],
        ["Personal financial data of real individuals", "NEVER USE", "Violates GDPR, CCPA, and numerous other privacy laws. Not needed for this project under any circumstances."],
        ["Leaked or unauthorised data", "NEVER USE", "Using leaked datasets (even ones posted publicly) is illegal in most jurisdictions and a career-ending decision in regulated industries."],
        ["Copyrighted commercial legal databases", "AVOID", "LexisNexis, Westlaw content is copyrighted and subscription-gated. Use official government sources (eur-lex.europa.eu, congress.gov, sec.gov) for all legal text — these are public domain."],
      ]).map(([type, status, why], i) => new TableRow({ children: [
        new TableCell({ borders: cellBorders, shading: { fill: i%2===0?C.white:C.light2, type: ShadingType.CLEAR }, width: { size: 2800, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 120, right: 120 }, children: [new Paragraph({ children: [bold(type, C.navy)] })] }),
        new TableCell({ borders: cellBorders, shading: { fill: i%2===0?C.white:C.light2, type: ShadingType.CLEAR }, width: { size: 1400, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 120, right: 120 }, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [bold(status, status === "NEVER USE" ? C.red : C.gold)] })] }),
        new TableCell({ borders: cellBorders, shading: { fill: i%2===0?C.white:C.light2, type: ShadingType.CLEAR }, width: { size: 5160, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 120, right: 120 }, children: [new Paragraph({ children: [run(why, { size: 19 })] })] }),
      ]}))
    ]
  }),
  new Paragraph({ spacing: sp(100, 0), children: [] }),

  h2("12.5  Evaluation Datasets — Generating Legitimate Benchmark Q&A Pairs"),
  para("To run RAGAS and DeepEval, you need a ground-truth evaluation dataset: a set of questions with known correct answers, grounded in your corpus. You have three legitimate approaches, which should be combined."),
  new Paragraph({ spacing: sp(80, 0), children: [] }),

  h3("Approach 1 — RAGAS Synthetic Generation (Recommended for Most Questions)"),
  para("RAGAS has a built-in testset generator that reads your ingested documents and automatically generates realistic question-answer pairs. This is the standard approach used in academic RAG papers."),
  bullet([bold("How it works: "), run("RAGAS reads your compliance documents, identifies key facts and requirements, and generates questions that test whether your system can retrieve and correctly answer them.")]),
  bullet([bold("Quality: "), run("High quality for factual, retrieval-testable questions. LLM-generated but grounded in real document content — which makes it legitimate for benchmarking.")]),
  bullet([bold("Quantity: "), run("Generate 100 to 200 questions from your compliance corpus. This is the industry standard evaluation set size for RAG systems.")]),
  bullet([bold("Portfolio claim: "), run("'Evaluated on 150 synthetically generated question-answer pairs grounded in PCI-DSS v4.0, DORA, and SEC EDGAR filings' — this is a fully legitimate and industry-standard claim.")]),
  new Paragraph({ spacing: sp(80, 0), children: [] }),

  h3("Approach 2 — FinanceBench (Peer-Reviewed Academic Benchmark)"),
  para([bold("FinanceBench"), run(" (github.com/patronus-ai/financebench) is a published academic benchmark dataset of 150 expert-curated financial question-answer pairs, grounded in real public SEC filings. Created by Patronus AI and published in a peer-reviewed paper.")]),
  bullet([bold("Legal status: "), run("Fully open, released for research and evaluation use. The underlying SEC filings are public domain.")]),
  bullet([bold("Questions cover: "), run("Revenue figures, profit margins, risk disclosures, segment performance, guidance language — exactly the kind of financial document queries FinOps Sentinel handles.")]),
  bullet([bold("Portfolio claim: "), run("'Benchmarked against FinanceBench — 150 expert-curated questions over public SEC filings' — this is the strongest possible evaluation claim because it is peer-reviewed and reproducible by anyone.")]),
  bullet([bold("Where to find it: "), run("github.com/patronus-ai/financebench — free, download immediately, no registration required.")]),
  new Paragraph({ spacing: sp(80, 0), children: [] }),

  h3("Approach 3 — Manual Expert Curation (For Cross-Corpus Queries)"),
  para("For the most important evaluation category — cross-corpus HYBRID queries that span both the code and compliance corpora — you will need to write these yourself because no existing benchmark tests this capability."),
  bullet([bold("Write 20 to 30 hand-crafted cross-corpus questions"), run(" such as: 'Which functions in the ccxt codebase handle API authentication, and what PCI-DSS v4.0 requirements apply to them?' or 'Does freqtrade's order execution flow comply with MiFID II best execution documentation requirements?'")]),
  bullet([bold("Write the ground truth answers manually"), run(" by reading both the code and the regulation yourself. This is time-consuming but creates a genuinely novel evaluation benchmark that no existing tool can generate for you.")]),
  bullet([bold("This becomes your unique contribution: "), run("A hand-curated cross-corpus evaluation dataset for FinTech compliance RAG. Consider publishing it as a separate GitHub repository — it has standalone academic and portfolio value.")]),
  new Paragraph({ spacing: sp(100, 0), children: [] }),

  h2("12.6  The Complete Dataset Plan by Phase"),
  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [800, 2100, 2100, 2200, 2160],
    rows: [
      new TableRow({ children: [
        ...["Phase", "Code Corpus", "Compliance Corpus", "Eval Dataset", "Expected Corpus Size"].map((t, i) => new TableCell({
          borders: cellBorders, shading: { fill: C.navy, type: ShadingType.CLEAR },
          width: { size: [800,2100,2100,2200,2160][i], type: WidthType.DXA },
          margins: { top: 100, bottom: 100, left: 100, right: 100 },
          children: [new Paragraph({ children: [new TextRun({ text: t, font: "Arial", size: 18, bold: true, color: C.white })] })]
        }))
      ]}),
      ...([
        ["1", "ccxt + freqtrade (~275K lines)", "PCI-DSS v4.0 + DORA (~500 pages)", "50 RAGAS synthetic Q&A pairs", "~3M tokens total"],
        ["2", "Same as Phase 1", "Add 3 to 5 SEC 10-K filings (~300 pages)", "Add FinanceBench (150 questions)", "~5M tokens total"],
        ["3", "Add OpenBB Terminal (~210K lines)", "Add FINRA Rulebook sections + NY DFS Part 500", "Add 30 manual cross-corpus Q&A pairs", "~8M tokens total"],
        ["4", "Add Goldman Sachs Legend (selectively)", "Add MiFID II + Basel III excerpts", "Full eval suite: 230+ questions, 3 sources", "~12M tokens total"],
      ]).map(([ph, code, comp, ev, size], i) => new TableRow({ children: [
        new TableCell({ borders: cellBorders, shading: { fill: i%2===0?C.white:C.light2, type: ShadingType.CLEAR }, width: { size: 800, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 100, right: 100 }, children: [new Paragraph({ alignment: AlignmentType.CENTER, children: [bold(`Ph ${ph}`, C.teal)] })] }),
        new TableCell({ borders: cellBorders, shading: { fill: i%2===0?C.white:C.light2, type: ShadingType.CLEAR }, width: { size: 2100, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 100, right: 100 }, children: [new Paragraph({ children: [run(code, { size: 19 })] })] }),
        new TableCell({ borders: cellBorders, shading: { fill: i%2===0?C.white:C.light2, type: ShadingType.CLEAR }, width: { size: 2100, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 100, right: 100 }, children: [new Paragraph({ children: [run(comp, { size: 19 })] })] }),
        new TableCell({ borders: cellBorders, shading: { fill: i%2===0?C.white:C.light2, type: ShadingType.CLEAR }, width: { size: 2200, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 100, right: 100 }, children: [new Paragraph({ children: [run(ev, { size: 19 })] })] }),
        new TableCell({ borders: cellBorders, shading: { fill: i%2===0?C.white:C.light2, type: ShadingType.CLEAR }, width: { size: 2160, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 100, right: 100 }, children: [new Paragraph({ children: [run(size, { size: 19, color: C.muted })] })] }),
      ]}))
    ]
  }),
  new Paragraph({ spacing: sp(100, 0), children: [] }),

  h2("12.7  How to State Your Metrics on Your Resume and README"),
  para("The exact wording of your metric claims matters. Here is the difference between a weak claim and a strong, verifiable one:"),
  new Paragraph({ spacing: sp(60, 0), children: [] }),

  new Table({
    width: { size: 9360, type: WidthType.DXA },
    columnWidths: [4680, 4680],
    rows: [
      new TableRow({ children: [
        new TableCell({ borders: cellBorders, shading: { fill: C.red, type: ShadingType.CLEAR }, width: { size: 4680, type: WidthType.DXA }, margins: { top: 100, bottom: 100, left: 160, right: 160 }, children: [new Paragraph({ children: [new TextRun({ text: "Weak claim (sounds made up)", font: "Arial", size: 20, bold: true, color: C.white })] })] }),
        new TableCell({ borders: cellBorders, shading: { fill: C.green, type: ShadingType.CLEAR }, width: { size: 4680, type: WidthType.DXA }, margins: { top: 100, bottom: 100, left: 160, right: 160 }, children: [new Paragraph({ children: [new TextRun({ text: "Strong claim (verifiable, specific)", font: "Arial", size: 20, bold: true, color: C.white })] })] }),
      ]}),
      ...([
        ["Achieved 93% faithfulness", "Achieved RAGAS faithfulness of 93.2% on 150-question FinanceBench evaluation over PCI-DSS v4.0 and SEC 10-K filings"],
        ["Reduced hallucinations significantly", "Reduced DeepEval hallucination rate from 11.4% (Phase 1 baseline) to 3.8% (Phase 2) by implementing Cohere Rerank v3 post-retrieval reranking"],
        ["Improved retrieval with hybrid search", "Hybrid BM25 + vector retrieval improved context precision from 0.71 to 0.89 (+25.4%) over pure vector baseline on 275,000-line open-source FinTech codebase (ccxt + freqtrade)"],
        ["Built a fast system", "P95 end-to-end query latency of 2.3 seconds on cross-corpus HYBRID queries against dual Chroma corpus (code + compliance namespaces) deployed on Render free tier"],
        ["Tested on real data", "Evaluated against FinanceBench (150 expert-curated questions, Patronus AI, 2024) and 30 hand-curated cross-corpus compliance mapping questions grounded in real open-source FinTech code"],
      ]).map(([weak, strong], i) => new TableRow({ children: [
        new TableCell({ borders: cellBorders, shading: { fill: i%2===0?C.white:"FFF5F5", type: ShadingType.CLEAR }, width: { size: 4680, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 160, right: 160 }, children: [new Paragraph({ children: [run(weak, { color: C.red })] })] }),
        new TableCell({ borders: cellBorders, shading: { fill: i%2===0?C.white:C.light2, type: ShadingType.CLEAR }, width: { size: 4680, type: WidthType.DXA }, margins: { top: 80, bottom: 80, left: 160, right: 160 }, children: [new Paragraph({ children: [run(strong, { color: C.green })] })] }),
      ]}))
    ]
  }),
  new Paragraph({ spacing: sp(80, 0), children: [] }),

  callout("FINAL RULE", "Every metric on your resume must be reproducible. Anyone reading your README should be able to clone your repo, run python evaluation/ragas_eval.py, and get the same numbers. If your metrics are not reproducible, they are not credible. The evaluation scripts in /evaluation/ are as important as the application code itself.", C.highlight, C.gold),

  pageBreak()
);

// FINAL PAGE
children.push(
  new Paragraph({ spacing: sp(600, 0), children: [] }),
  new Paragraph({ alignment: AlignmentType.CENTER, children: [new TextRun({ text: "FinOps Sentinel", font: "Arial", size: 52, bold: true, color: C.navy })] }),
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: sp(40, 40), children: [new TextRun({ text: "Master Project Document  ·  v1.0  ·  March 2026", font: "Arial", size: 22, color: C.muted })] }),
  divider(C.teal),
  new Paragraph({ alignment: AlignmentType.CENTER, spacing: sp(120, 0), children: [new TextRun({ text: "This document is a living artifact. Update it. Own it. It is your engineering story.", font: "Arial", size: 22, color: C.teal, italics: true })] }),
);

// ═══════════════════════════════════════════════════════════════════════════
// ASSEMBLE & WRITE
// ═══════════════════════════════════════════════════════════════════════════
const doc = new Document({
  numbering: {
    config: [
      { reference: "bullets", levels: [
        { level: 0, format: LevelFormat.BULLET, text: "\u2022", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 560, hanging: 280 } } } },
        { level: 1, format: LevelFormat.BULLET, text: "\u25E6", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 900, hanging: 280 } } } },
      ]},
      { reference: "numbers", levels: [{ level: 0, format: LevelFormat.DECIMAL, text: "%1.", alignment: AlignmentType.LEFT, style: { paragraph: { indent: { left: 560, hanging: 280 } } } }] },
    ]
  },
  styles: {
    default: { document: { run: { font: "Arial", size: 22 } } },
    paragraphStyles: [
      { id: "Heading1", name: "Heading 1", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 34, bold: true, font: "Arial", color: C.navy },
        paragraph: { spacing: { before: 360, after: 120 }, outlineLevel: 0 } },
      { id: "Heading2", name: "Heading 2", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 28, bold: true, font: "Arial", color: C.teal },
        paragraph: { spacing: { before: 280, after: 100 }, outlineLevel: 1 } },
      { id: "Heading3", name: "Heading 3", basedOn: "Normal", next: "Normal", quickFormat: true,
        run: { size: 24, bold: true, font: "Arial", color: C.navy },
        paragraph: { spacing: { before: 200, after: 80 }, outlineLevel: 2 } },
    ]
  },
  sections: [{
    properties: {
      page: {
        size: { width: 12240, height: 15840 },
        margin: { top: 1260, right: 1260, bottom: 1260, left: 1440 }
      }
    },
    headers: {
      default: new Header({ children: [
        new Paragraph({
          alignment: AlignmentType.RIGHT,
          border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: C.teal, space: 1 } },
          spacing: { before: 0, after: 160 },
          children: [
            new TextRun({ text: "FinOps Sentinel  ·  Master Project Document  ·  ", font: "Arial", size: 18, color: C.muted }),
            new TextRun({ text: "v1.0", font: "Arial", size: 18, bold: true, color: C.teal }),
          ]
        })
      ]})
    },
    footers: {
      default: new Footer({ children: [
        new Paragraph({
          alignment: AlignmentType.CENTER,
          border: { top: { style: BorderStyle.SINGLE, size: 4, color: C.border, space: 1 } },
          spacing: { before: 160, after: 0 },
          children: [
            new TextRun({ text: "Confidential — Portfolio Document  ·  Update build log after every session", font: "Arial", size: 18, color: C.muted }),
          ]
        })
      ]})
    },
    children
  }]
});

Packer.toBuffer(doc).then(buf => {
  fs.writeFileSync("/home/claude/FinOps_Sentinel_Master_Document.docx", buf);
  console.log("DONE");
});
